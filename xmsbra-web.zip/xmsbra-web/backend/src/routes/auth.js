// XMSBRA API - Authentication Routes
import { Hono } from 'hono';
import { sign, verify } from 'jose';
import { authService } from '../services/auth.js';
import { kvService } from '../services/kv.js';

const auth = new Hono();

// Token-based login
auth.post('/token-login', async (c) => {
  try {
    const { token } = await c.req.json();
    
    if (!token) {
      return c.json({ 
        success: false, 
        message: 'Access token is required' 
      }, 400);
    }

    // Validate token and get user role
    const userRole = await authService.validateAccessToken(c.env, token);
    
    if (!userRole) {
      return c.json({ 
        success: false, 
        message: 'Invalid access token' 
      }, 401);
    }

    // Generate JWT token
    const jwtToken = await authService.generateJWT(c.env, {
      role: userRole,
      token: token,
      loginTime: Date.now()
    });

    // Create user object
    const user = {
      id: `user_${userRole}_${Date.now()}`,
      role: userRole,
      username: `${userRole}_user`,
      loginTime: new Date().toISOString(),
      permissions: authService.getRolePermissions(userRole)
    };

    // Store session in KV
    await kvService.setSession(c.env, user.id, {
      user,
      token: jwtToken,
      accessToken: token,
      expiresAt: Date.now() + (24 * 60 * 60 * 1000) // 24 hours
    });

    // Log login activity
    await kvService.logActivity(c.env, {
      userId: user.id,
      action: 'login',
      details: `User logged in with ${userRole} role`,
      timestamp: new Date().toISOString(),
      ip: c.req.header('CF-Connecting-IP') || 'unknown'
    });

    return c.json({
      success: true,
      message: 'Login successful',
      accessToken: jwtToken,
      user: user
    });

  } catch (error) {
    console.error('Token login error:', error);
    return c.json({ 
      success: false, 
      message: 'Internal server error' 
    }, 500);
  }
});

// Validate JWT token
auth.get('/validate', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return c.json({ 
        success: false, 
        message: 'Authorization header required' 
      }, 401);
    }

    const token = authHeader.substring(7);
    const payload = await authService.verifyJWT(c.env, token);
    
    if (!payload) {
      return c.json({ 
        success: false, 
        message: 'Invalid or expired token' 
      }, 401);
    }

    // Get session from KV
    const session = await kvService.getSession(c.env, payload.sub);
    
    if (!session || session.expiresAt < Date.now()) {
      return c.json({ 
        success: false, 
        message: 'Session expired' 
      }, 401);
    }

    return c.json({
      success: true,
      user: session.user,
      expiresAt: session.expiresAt
    });

  } catch (error) {
    console.error('Token validation error:', error);
    return c.json({ 
      success: false, 
      message: 'Token validation failed' 
    }, 401);
  }
});

// Refresh JWT token
auth.post('/refresh', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return c.json({ 
        success: false, 
        message: 'Authorization header required' 
      }, 401);
    }

    const token = authHeader.substring(7);
    const payload = await authService.verifyJWT(c.env, token);
    
    if (!payload) {
      return c.json({ 
        success: false, 
        message: 'Invalid token' 
      }, 401);
    }

    // Get session from KV
    const session = await kvService.getSession(c.env, payload.sub);
    
    if (!session) {
      return c.json({ 
        success: false, 
        message: 'Session not found' 
      }, 401);
    }

    // Generate new JWT token
    const newJwtToken = await authService.generateJWT(c.env, {
      role: session.user.role,
      token: session.accessToken,
      loginTime: session.user.loginTime
    });

    // Update session
    session.token = newJwtToken;
    session.expiresAt = Date.now() + (24 * 60 * 60 * 1000); // Extend 24 hours
    
    await kvService.setSession(c.env, session.user.id, session);

    return c.json({
      success: true,
      token: newJwtToken,
      expiresAt: session.expiresAt
    });

  } catch (error) {
    console.error('Token refresh error:', error);
    return c.json({ 
      success: false, 
      message: 'Token refresh failed' 
    }, 500);
  }
});

// Logout
auth.post('/logout', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const payload = await authService.verifyJWT(c.env, token);
      
      if (payload) {
        // Remove session from KV
        await kvService.deleteSession(c.env, payload.sub);
        
        // Log logout activity
        await kvService.logActivity(c.env, {
          userId: payload.sub,
          action: 'logout',
          details: 'User logged out',
          timestamp: new Date().toISOString(),
          ip: c.req.header('CF-Connecting-IP') || 'unknown'
        });
      }
    }

    return c.json({
      success: true,
      message: 'Logout successful'
    });

  } catch (error) {
    console.error('Logout error:', error);
    return c.json({ 
      success: false, 
      message: 'Logout failed' 
    }, 500);
  }
});

// Generate new access token (Owner only)
auth.post('/generate-token', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return c.json({ 
        success: false, 
        message: 'Authorization header required' 
      }, 401);
    }

    const token = authHeader.substring(7);
    const payload = await authService.verifyJWT(c.env, token);
    
    if (!payload) {
      return c.json({ 
        success: false, 
        message: 'Invalid token' 
      }, 401);
    }

    // Get session and check if user is owner
    const session = await kvService.getSession(c.env, payload.sub);
    
    if (!session || session.user.role !== 'owner') {
      return c.json({ 
        success: false, 
        message: 'Only owners can generate access tokens' 
      }, 403);
    }

    const { role, description } = await c.req.json();
    
    if (!role || !['owner', 'admin', 'premium'].includes(role)) {
      return c.json({ 
        success: false, 
        message: 'Invalid role specified' 
      }, 400);
    }

    // Generate new access token
    const newAccessToken = await authService.generateAccessToken(c.env, role, description);
    
    // Store token info in KV
    await kvService.storeAccessToken(c.env, newAccessToken, {
      role,
      description: description || `${role} access token`,
      createdBy: session.user.id,
      createdAt: new Date().toISOString(),
      isActive: true
    });

    // Log token generation
    await kvService.logActivity(c.env, {
      userId: session.user.id,
      action: 'generate_token',
      details: `Generated ${role} access token: ${description || 'No description'}`,
      timestamp: new Date().toISOString(),
      ip: c.req.header('CF-Connecting-IP') || 'unknown'
    });

    return c.json({
      success: true,
      message: 'Access token generated successfully',
      token: newAccessToken,
      role,
      description: description || `${role} access token`,
      createdAt: new Date().toISOString()
    });

  } catch (error) {
    console.error('Token generation error:', error);
    return c.json({ 
      success: false, 
      message: 'Token generation failed' 
    }, 500);
  }
});

// List access tokens (Owner only)
auth.get('/tokens', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return c.json({ 
        success: false, 
        message: 'Authorization header required' 
      }, 401);
    }

    const token = authHeader.substring(7);
    const payload = await authService.verifyJWT(c.env, token);
    
    if (!payload) {
      return c.json({ 
        success: false, 
        message: 'Invalid token' 
      }, 401);
    }

    // Get session and check if user is owner
    const session = await kvService.getSession(c.env, payload.sub);
    
    if (!session || session.user.role !== 'owner') {
      return c.json({ 
        success: false, 
        message: 'Only owners can view access tokens' 
      }, 403);
    }

    // Get all access tokens
    const tokens = await kvService.getAllAccessTokens(c.env);

    return c.json({
      success: true,
      tokens
    });

  } catch (error) {
    console.error('List tokens error:', error);
    return c.json({ 
      success: false, 
      message: 'Failed to list tokens' 
    }, 500);
  }
});

// Revoke access token (Owner only)
auth.delete('/tokens/:token', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return c.json({ 
        success: false, 
        message: 'Authorization header required' 
      }, 401);
    }

    const jwtToken = authHeader.substring(7);
    const payload = await authService.verifyJWT(c.env, jwtToken);
    
    if (!payload) {
      return c.json({ 
        success: false, 
        message: 'Invalid token' 
      }, 401);
    }

    // Get session and check if user is owner
    const session = await kvService.getSession(c.env, payload.sub);
    
    if (!session || session.user.role !== 'owner') {
      return c.json({ 
        success: false, 
        message: 'Only owners can revoke access tokens' 
      }, 403);
    }

    const tokenToRevoke = c.req.param('token');
    
    // Revoke token
    await kvService.revokeAccessToken(c.env, tokenToRevoke);

    // Log token revocation
    await kvService.logActivity(c.env, {
      userId: session.user.id,
      action: 'revoke_token',
      details: `Revoked access token: ${tokenToRevoke}`,
      timestamp: new Date().toISOString(),
      ip: c.req.header('CF-Connecting-IP') || 'unknown'
    });

    return c.json({
      success: true,
      message: 'Access token revoked successfully'
    });

  } catch (error) {
    console.error('Token revocation error:', error);
    return c.json({ 
      success: false, 
      message: 'Token revocation failed' 
    }, 500);
  }
});

export default auth;

