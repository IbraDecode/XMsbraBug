// XMSBRA API - Sender Management Routes
import { Hono } from 'hono';
import { authService } from '../services/auth.js';
import { kvService } from '../services/kv.js';
import { whatsappService } from '../services/whatsapp.js';

const sender = new Hono();

// Middleware to check sender permission
const checkSenderPermission = async (c, next) => {
  const authHeader = c.req.header('Authorization');
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return c.json({ 
      success: false, 
      message: 'Authorization required' 
    }, 401);
  }

  const token = authHeader.substring(7);
  const payload = await authService.verifyJWT(c.env, token);
  
  if (!payload) {
    return c.json({ 
      success: false, 
      message: 'Invalid token' 
    }, 401);
  }

  const session = await kvService.getSession(c.env, payload.sub);
  
  if (!session) {
    return c.json({ 
      success: false, 
      message: 'Session not found' 
    }, 401);
  }

  c.set('user', session.user);
  await next();
};

// Apply permission middleware to all sender routes
sender.use('*', checkSenderPermission);

// Add new sender
sender.post('/add', async (c) => {
  try {
    const { phoneNumber } = await c.req.json();
    const user = c.get('user');
    
    if (!authService.hasPermission(user.role, 'add_sender')) {
      return c.json({
        success: false,
        message: 'Insufficient permissions to add sender'
      }, 403);
    }

    if (!phoneNumber) {
      return c.json({
        success: false,
        message: 'Phone number is required'
      }, 400);
    }

    // Validate phone number format
    const cleanPhone = phoneNumber.replace(/\D/g, '');
    if (cleanPhone.length < 10 || cleanPhone.length > 15) {
      return c.json({
        success: false,
        message: 'Invalid phone number format'
      }, 400);
    }

    // Format phone number
    const formattedPhone = cleanPhone.startsWith('62') ? cleanPhone : '62' + cleanPhone.replace(/^0/, '');
    
    // Generate session ID
    const sessionId = `session_${formattedPhone}_${Date.now()}`;
    
    // Check if sender already exists
    const existingSenders = await kvService.getAllSenders(c.env);
    const existingSender = existingSenders.find(s => s.phoneNumber === formattedPhone);
    
    if (existingSender) {
      return c.json({
        success: false,
        message: 'Phone number already registered as sender'
      }, 400);
    }

    // Check sender limit based on user role
    const config = await kvService.getConfig(c.env);
    const maxSenders = user.role === 'owner' ? config.maxSessions : 
                      user.role === 'admin' ? Math.floor(config.maxSessions / 2) : 3;
    
    if (existingSenders.length >= maxSenders) {
      return c.json({
        success: false,
        message: `Maximum sender limit reached (${maxSenders})`
      }, 400);
    }

    // Initialize WhatsApp session
    const initResult = await whatsappService.initializeSession(c.env, {
      sessionId,
      phoneNumber: formattedPhone,
      userId: user.id
    });

    if (!initResult.success) {
      return c.json({
        success: false,
        message: initResult.error || 'Failed to initialize WhatsApp session'
      }, 500);
    }

    // Store sender data
    const senderData = {
      phoneNumber: formattedPhone,
      sessionId,
      status: 'pairing',
      createdBy: user.id,
      createdAt: new Date().toISOString(),
      lastActive: new Date().toISOString(),
      pairingCode: initResult.pairingCode,
      qrCode: initResult.qrCode || null
    };

    await kvService.storeSender(c.env, sessionId, senderData);

    // Log activity
    await kvService.logActivity(c.env, {
      userId: user.id,
      action: 'sender_added',
      details: `Added new sender: ${formattedPhone} (${sessionId})`,
      timestamp: new Date().toISOString(),
      ip: c.req.header('CF-Connecting-IP') || 'unknown'
    });

    // Update stats
    await kvService.updateStats(c.env, 'activeSenders');

    return c.json({
      success: true,
      message: 'Sender added successfully',
      sender: {
        sessionId,
        phoneNumber: formattedPhone,
        status: 'pairing',
        pairingCode: initResult.pairingCode,
        qrCode: initResult.qrCode
      }
    });

  } catch (error) {
    console.error('Add sender error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

// List all senders
sender.get('/list', async (c) => {
  try {
    const user = c.get('user');
    
    if (!authService.hasPermission(user.role, 'list_sender')) {
      return c.json({
        success: false,
        message: 'Insufficient permissions to list senders'
      }, 403);
    }

    const allSenders = await kvService.getAllSenders(c.env);
    
    // Filter senders based on user role
    let senders = allSenders;
    if (user.role !== 'owner') {
      // Non-owners can only see their own senders
      senders = allSenders.filter(s => s.createdBy === user.id);
    }

    // Get detailed status for each sender
    const sendersWithStatus = await Promise.all(
      senders.map(async (sender) => {
        const detailedSender = await kvService.getSender(c.env, sender.sessionId);
        const status = await whatsappService.getSessionStatus(c.env, sender.sessionId);
        
        return {
          sessionId: sender.sessionId,
          phoneNumber: sender.phoneNumber,
          status: status.connected ? 'connected' : 
                  status.connecting ? 'connecting' : 
                  detailedSender?.status || 'disconnected',
          lastActive: detailedSender?.lastActive || sender.createdAt,
          createdAt: sender.createdAt,
          createdBy: sender.createdBy,
          qrCode: status.qrCode || null,
          pairingCode: detailedSender?.pairingCode || null
        };
      })
    );

    return c.json({
      success: true,
      senders: sendersWithStatus,
      total: sendersWithStatus.length
    });

  } catch (error) {
    console.error('List senders error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

// Get sender status
sender.get('/status/:sessionId', async (c) => {
  try {
    const sessionId = c.req.param('sessionId');
    const user = c.get('user');
    
    if (!sessionId) {
      return c.json({
        success: false,
        message: 'Session ID is required'
      }, 400);
    }

    const senderData = await kvService.getSender(c.env, sessionId);
    
    if (!senderData) {
      return c.json({
        success: false,
        message: 'Sender not found'
      }, 404);
    }

    // Check if user has permission to view this sender
    if (user.role !== 'owner' && senderData.createdBy !== user.id) {
      return c.json({
        success: false,
        message: 'Insufficient permissions to view this sender'
      }, 403);
    }

    // Get real-time status from WhatsApp service
    const status = await whatsappService.getSessionStatus(c.env, sessionId);
    
    const detailedStatus = {
      sessionId,
      phoneNumber: senderData.phoneNumber,
      status: status.connected ? 'connected' : 
              status.connecting ? 'connecting' : 
              senderData.status || 'disconnected',
      lastActive: senderData.lastActive,
      createdAt: senderData.createdAt,
      createdBy: senderData.createdBy,
      connectionInfo: {
        connected: status.connected,
        connecting: status.connecting,
        qrCode: status.qrCode,
        pairingCode: senderData.pairingCode,
        lastSeen: status.lastSeen,
        battery: status.battery,
        pushName: status.pushName
      },
      stats: {
        messagesSent: status.messagesSent || 0,
        messagesReceived: status.messagesReceived || 0,
        uptime: status.uptime || 0
      }
    };

    return c.json({
      success: true,
      sender: detailedStatus
    });

  } catch (error) {
    console.error('Get sender status error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

// Connect sender
sender.post('/connect/:sessionId', async (c) => {
  try {
    const sessionId = c.req.param('sessionId');
    const user = c.get('user');
    
    if (!sessionId) {
      return c.json({
        success: false,
        message: 'Session ID is required'
      }, 400);
    }

    const senderData = await kvService.getSender(c.env, sessionId);
    
    if (!senderData) {
      return c.json({
        success: false,
        message: 'Sender not found'
      }, 404);
    }

    // Check permissions
    if (user.role !== 'owner' && senderData.createdBy !== user.id) {
      return c.json({
        success: false,
        message: 'Insufficient permissions to connect this sender'
      }, 403);
    }

    // Connect WhatsApp session
    const connectResult = await whatsappService.connectSession(c.env, sessionId);
    
    if (connectResult.success) {
      // Update sender status
      senderData.status = 'connecting';
      senderData.lastActive = new Date().toISOString();
      await kvService.storeSender(c.env, sessionId, senderData);

      // Log activity
      await kvService.logActivity(c.env, {
        userId: user.id,
        action: 'sender_connect',
        details: `Connected sender: ${senderData.phoneNumber} (${sessionId})`,
        timestamp: new Date().toISOString(),
        ip: c.req.header('CF-Connecting-IP') || 'unknown'
      });

      return c.json({
        success: true,
        message: 'Sender connection initiated',
        sessionId,
        status: 'connecting',
        qrCode: connectResult.qrCode,
        pairingCode: connectResult.pairingCode
      });
    } else {
      return c.json({
        success: false,
        message: connectResult.error || 'Failed to connect sender'
      }, 500);
    }

  } catch (error) {
    console.error('Connect sender error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

// Disconnect sender
sender.post('/disconnect/:sessionId', async (c) => {
  try {
    const sessionId = c.req.param('sessionId');
    const user = c.get('user');
    
    if (!sessionId) {
      return c.json({
        success: false,
        message: 'Session ID is required'
      }, 400);
    }

    const senderData = await kvService.getSender(c.env, sessionId);
    
    if (!senderData) {
      return c.json({
        success: false,
        message: 'Sender not found'
      }, 404);
    }

    // Check permissions
    if (user.role !== 'owner' && senderData.createdBy !== user.id) {
      return c.json({
        success: false,
        message: 'Insufficient permissions to disconnect this sender'
      }, 403);
    }

    // Disconnect WhatsApp session
    const disconnectResult = await whatsappService.disconnectSession(c.env, sessionId);
    
    if (disconnectResult.success) {
      // Update sender status
      senderData.status = 'disconnected';
      senderData.lastActive = new Date().toISOString();
      await kvService.storeSender(c.env, sessionId, senderData);

      // Log activity
      await kvService.logActivity(c.env, {
        userId: user.id,
        action: 'sender_disconnect',
        details: `Disconnected sender: ${senderData.phoneNumber} (${sessionId})`,
        timestamp: new Date().toISOString(),
        ip: c.req.header('CF-Connecting-IP') || 'unknown'
      });

      return c.json({
        success: true,
        message: 'Sender disconnected successfully',
        sessionId,
        status: 'disconnected'
      });
    } else {
      return c.json({
        success: false,
        message: disconnectResult.error || 'Failed to disconnect sender'
      }, 500);
    }

  } catch (error) {
    console.error('Disconnect sender error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

// Delete sender
sender.delete('/delete/:sessionId', async (c) => {
  try {
    const sessionId = c.req.param('sessionId');
    const user = c.get('user');
    
    if (!authService.hasPermission(user.role, 'delete_sender')) {
      return c.json({
        success: false,
        message: 'Insufficient permissions to delete sender'
      }, 403);
    }

    if (!sessionId) {
      return c.json({
        success: false,
        message: 'Session ID is required'
      }, 400);
    }

    const senderData = await kvService.getSender(c.env, sessionId);
    
    if (!senderData) {
      return c.json({
        success: false,
        message: 'Sender not found'
      }, 404);
    }

    // Check permissions (non-owners can only delete their own senders)
    if (user.role !== 'owner' && senderData.createdBy !== user.id) {
      return c.json({
        success: false,
        message: 'Insufficient permissions to delete this sender'
      }, 403);
    }

    // Disconnect and cleanup WhatsApp session
    await whatsappService.disconnectSession(c.env, sessionId);
    await whatsappService.cleanupSession(c.env, sessionId);

    // Delete sender from storage
    await kvService.deleteSender(c.env, sessionId);

    // Log activity
    await kvService.logActivity(c.env, {
      userId: user.id,
      action: 'sender_deleted',
      details: `Deleted sender: ${senderData.phoneNumber} (${sessionId})`,
      timestamp: new Date().toISOString(),
      ip: c.req.header('CF-Connecting-IP') || 'unknown'
    });

    // Update stats
    await kvService.updateStats(c.env, 'activeSenders', -1);

    return c.json({
      success: true,
      message: 'Sender deleted successfully',
      sessionId
    });

  } catch (error) {
    console.error('Delete sender error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

// Get QR code for pairing
sender.get('/qr/:sessionId', async (c) => {
  try {
    const sessionId = c.req.param('sessionId');
    const user = c.get('user');
    
    if (!sessionId) {
      return c.json({
        success: false,
        message: 'Session ID is required'
      }, 400);
    }

    const senderData = await kvService.getSender(c.env, sessionId);
    
    if (!senderData) {
      return c.json({
        success: false,
        message: 'Sender not found'
      }, 404);
    }

    // Check permissions
    if (user.role !== 'owner' && senderData.createdBy !== user.id) {
      return c.json({
        success: false,
        message: 'Insufficient permissions to view QR code'
      }, 403);
    }

    // Get current QR code
    const qrResult = await whatsappService.getQRCode(c.env, sessionId);
    
    if (qrResult.success) {
      return c.json({
        success: true,
        sessionId,
        qrCode: qrResult.qrCode,
        pairingCode: qrResult.pairingCode,
        expiresAt: qrResult.expiresAt
      });
    } else {
      return c.json({
        success: false,
        message: qrResult.error || 'QR code not available'
      }, 404);
    }

  } catch (error) {
    console.error('Get QR code error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

// Restart sender session
sender.post('/restart/:sessionId', async (c) => {
  try {
    const sessionId = c.req.param('sessionId');
    const user = c.get('user');
    
    if (!sessionId) {
      return c.json({
        success: false,
        message: 'Session ID is required'
      }, 400);
    }

    const senderData = await kvService.getSender(c.env, sessionId);
    
    if (!senderData) {
      return c.json({
        success: false,
        message: 'Sender not found'
      }, 404);
    }

    // Check permissions (only owner or creator can restart)
    if (user.role !== 'owner' && senderData.createdBy !== user.id) {
      return c.json({
        success: false,
        message: 'Insufficient permissions to restart this sender'
      }, 403);
    }

    // Restart WhatsApp session
    const restartResult = await whatsappService.restartSession(c.env, sessionId);
    
    if (restartResult.success) {
      // Update sender status
      senderData.status = 'connecting';
      senderData.lastActive = new Date().toISOString();
      await kvService.storeSender(c.env, sessionId, senderData);

      // Log activity
      await kvService.logActivity(c.env, {
        userId: user.id,
        action: 'sender_restart',
        details: `Restarted sender: ${senderData.phoneNumber} (${sessionId})`,
        timestamp: new Date().toISOString(),
        ip: c.req.header('CF-Connecting-IP') || 'unknown'
      });

      return c.json({
        success: true,
        message: 'Sender restarted successfully',
        sessionId,
        status: 'connecting'
      });
    } else {
      return c.json({
        success: false,
        message: restartResult.error || 'Failed to restart sender'
      }, 500);
    }

  } catch (error) {
    console.error('Restart sender error:', error);
    return c.json({
      success: false,
      message: 'Internal server error'
    }, 500);
  }
});

export default sender;

