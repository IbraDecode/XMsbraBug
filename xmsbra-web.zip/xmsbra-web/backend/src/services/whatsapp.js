// XMSBRA API - WhatsApp Service
// This service handles WhatsApp operations adapted from the original index.js

export const whatsappService = {
  // Initialize WhatsApp session
  async initializeSession(env, { sessionId, phoneNumber, userId }) {
    try {
      // Generate pairing code (8-digit code)
      const pairingCode = Math.floor(10000000 + Math.random() * 90000000).toString();
      
      // Store session initialization data
      const sessionData = {
        sessionId,
        phoneNumber,
        userId,
        status: 'initializing',
        pairingCode,
        createdAt: new Date().toISOString(),
        lastActivity: new Date().toISOString()
      };

      await env.XMSBRA_KV.put(
        `wa_session:${sessionId}`,
        JSON.stringify(sessionData),
        { expirationTtl: 86400 } // 24 hours
      );

      return {
        success: true,
        sessionId,
        pairingCode,
        message: 'Session initialized successfully'
      };

    } catch (error) {
      console.error('Initialize session error:', error);
      return {
        success: false,
        error: 'Failed to initialize WhatsApp session'
      };
    }
  },

  // Connect WhatsApp session
  async connectSession(env, sessionId) {
    try {
      const sessionData = await this.getSessionData(env, sessionId);
      
      if (!sessionData) {
        return {
          success: false,
          error: 'Session not found'
        };
      }

      // Update session status
      sessionData.status = 'connecting';
      sessionData.lastActivity = new Date().toISOString();
      
      await env.XMSBRA_KV.put(
        `wa_session:${sessionId}`,
        JSON.stringify(sessionData),
        { expirationTtl: 86400 }
      );

      // Generate new QR code if needed
      const qrCode = await this.generateQRCode(sessionId);

      return {
        success: true,
        sessionId,
        status: 'connecting',
        qrCode,
        pairingCode: sessionData.pairingCode
      };

    } catch (error) {
      console.error('Connect session error:', error);
      return {
        success: false,
        error: 'Failed to connect WhatsApp session'
      };
    }
  },

  // Disconnect WhatsApp session
  async disconnectSession(env, sessionId) {
    try {
      const sessionData = await this.getSessionData(env, sessionId);
      
      if (!sessionData) {
        return {
          success: false,
          error: 'Session not found'
        };
      }

      // Update session status
      sessionData.status = 'disconnected';
      sessionData.lastActivity = new Date().toISOString();
      
      await env.XMSBRA_KV.put(
        `wa_session:${sessionId}`,
        JSON.stringify(sessionData),
        { expirationTtl: 86400 }
      );

      return {
        success: true,
        sessionId,
        status: 'disconnected'
      };

    } catch (error) {
      console.error('Disconnect session error:', error);
      return {
        success: false,
        error: 'Failed to disconnect WhatsApp session'
      };
    }
  },

  // Get session status
  async getSessionStatus(env, sessionId) {
    try {
      const sessionData = await this.getSessionData(env, sessionId);
      
      if (!sessionData) {
        return {
          connected: false,
          connecting: false,
          status: 'not_found'
        };
      }

      // Simulate connection status based on time and session data
      const now = Date.now();
      const lastActivity = new Date(sessionData.lastActivity).getTime();
      const timeDiff = now - lastActivity;
      
      // Consider session connected if last activity was within 5 minutes
      const isConnected = timeDiff < 300000 && sessionData.status === 'connected';
      const isConnecting = sessionData.status === 'connecting';

      return {
        connected: isConnected,
        connecting: isConnecting,
        status: sessionData.status,
        lastSeen: sessionData.lastActivity,
        phoneNumber: sessionData.phoneNumber,
        qrCode: isConnecting ? await this.generateQRCode(sessionId) : null,
        pairingCode: sessionData.pairingCode,
        battery: Math.floor(Math.random() * 100), // Simulated battery level
        pushName: sessionData.pushName || 'XMSBRA Bot',
        messagesSent: sessionData.messagesSent || 0,
        messagesReceived: sessionData.messagesReceived || 0,
        uptime: timeDiff
      };

    } catch (error) {
      console.error('Get session status error:', error);
      return {
        connected: false,
        connecting: false,
        status: 'error'
      };
    }
  },

  // Send Xata Force Delay bug (adapted from original index.js)
  async sendXataDelay(env, { target, sessionId, sender }) {
    try {
      const sessionData = await this.getSessionData(env, sessionId);
      
      if (!sessionData || sessionData.status !== 'connected') {
        return {
          success: false,
          error: 'Session not connected'
        };
      }

      // Simulate sending xata delay bug message
      const bugMessage = this.generateXataDelayPayload();
      
      // Log the bug send attempt
      const logData = {
        sessionId,
        target,
        type: 'xata_delay',
        payload: bugMessage,
        timestamp: new Date().toISOString(),
        status: 'sent'
      };

      await env.XMSBRA_KV.put(
        `bug_log:${Date.now()}_${sessionId}`,
        JSON.stringify(logData),
        { expirationTtl: 604800 } // 7 days
      );

      // Update session stats
      sessionData.messagesSent = (sessionData.messagesSent || 0) + 1;
      sessionData.lastActivity = new Date().toISOString();
      
      await env.XMSBRA_KV.put(
        `wa_session:${sessionId}`,
        JSON.stringify(sessionData),
        { expirationTtl: 86400 }
      );

      return {
        success: true,
        message: 'Xata delay bug sent successfully',
        target,
        sessionId,
        sentAt: new Date().toISOString()
      };

    } catch (error) {
      console.error('Send xata delay error:', error);
      return {
        success: false,
        error: 'Failed to send xata delay bug'
      };
    }
  },

  // Send Force Close bug
  async sendForceClose(env, { target, sessionId, sender }) {
    try {
      const sessionData = await this.getSessionData(env, sessionId);
      
      if (!sessionData || sessionData.status !== 'connected') {
        return {
          success: false,
          error: 'Session not connected'
        };
      }

      // Simulate sending force close bug message
      const bugMessage = this.generateForceClosePayload();
      
      // Log the bug send attempt
      const logData = {
        sessionId,
        target,
        type: 'force_close',
        payload: bugMessage,
        timestamp: new Date().toISOString(),
        status: 'sent'
      };

      await env.XMSBRA_KV.put(
        `bug_log:${Date.now()}_${sessionId}`,
        JSON.stringify(logData),
        { expirationTtl: 604800 } // 7 days
      );

      // Update session stats
      sessionData.messagesSent = (sessionData.messagesSent || 0) + 1;
      sessionData.lastActivity = new Date().toISOString();
      
      await env.XMSBRA_KV.put(
        `wa_session:${sessionId}`,
        JSON.stringify(sessionData),
        { expirationTtl: 86400 }
      );

      return {
        success: true,
        message: 'Force close bug sent successfully',
        target,
        sessionId,
        sentAt: new Date().toISOString()
      };

    } catch (error) {
      console.error('Send force close error:', error);
      return {
        success: false,
        error: 'Failed to send force close bug'
      };
    }
  },

  // Send Crash Target bug
  async sendCrashTarget(env, { target, sessionId, sender }) {
    try {
      const sessionData = await this.getSessionData(env, sessionId);
      
      if (!sessionData || sessionData.status !== 'connected') {
        return {
          success: false,
          error: 'Session not connected'
        };
      }

      // Simulate sending crash target bug message
      const bugMessage = this.generateCrashTargetPayload();
      
      // Log the bug send attempt
      const logData = {
        sessionId,
        target,
        type: 'crash_target',
        payload: bugMessage,
        timestamp: new Date().toISOString(),
        status: 'sent'
      };

      await env.XMSBRA_KV.put(
        `bug_log:${Date.now()}_${sessionId}`,
        JSON.stringify(logData),
        { expirationTtl: 604800 } // 7 days
      );

      // Update session stats
      sessionData.messagesSent = (sessionData.messagesSent || 0) + 1;
      sessionData.lastActivity = new Date().toISOString();
      
      await env.XMSBRA_KV.put(
        `wa_session:${sessionId}`,
        JSON.stringify(sessionData),
        { expirationTtl: 86400 }
      );

      return {
        success: true,
        message: 'Crash target bug sent successfully',
        target,
        sessionId,
        sentAt: new Date().toISOString()
      };

    } catch (error) {
      console.error('Send crash target error:', error);
      return {
        success: false,
        error: 'Failed to send crash target bug'
      };
    }
  },

  // Get QR code for session
  async getQRCode(env, sessionId) {
    try {
      const qrCode = await this.generateQRCode(sessionId);
      const sessionData = await this.getSessionData(env, sessionId);
      
      if (!sessionData) {
        return {
          success: false,
          error: 'Session not found'
        };
      }

      return {
        success: true,
        qrCode,
        pairingCode: sessionData.pairingCode,
        expiresAt: new Date(Date.now() + 120000).toISOString() // 2 minutes
      };

    } catch (error) {
      console.error('Get QR code error:', error);
      return {
        success: false,
        error: 'Failed to generate QR code'
      };
    }
  },

  // Restart session
  async restartSession(env, sessionId) {
    try {
      const sessionData = await this.getSessionData(env, sessionId);
      
      if (!sessionData) {
        return {
          success: false,
          error: 'Session not found'
        };
      }

      // Reset session data
      sessionData.status = 'connecting';
      sessionData.lastActivity = new Date().toISOString();
      sessionData.pairingCode = Math.floor(10000000 + Math.random() * 90000000).toString();
      
      await env.XMSBRA_KV.put(
        `wa_session:${sessionId}`,
        JSON.stringify(sessionData),
        { expirationTtl: 86400 }
      );

      return {
        success: true,
        sessionId,
        status: 'connecting',
        pairingCode: sessionData.pairingCode
      };

    } catch (error) {
      console.error('Restart session error:', error);
      return {
        success: false,
        error: 'Failed to restart session'
      };
    }
  },

  // Cleanup session
  async cleanupSession(env, sessionId) {
    try {
      await env.XMSBRA_KV.delete(`wa_session:${sessionId}`);
      
      // Clean up related data
      const keys = await env.XMSBRA_KV.list({ prefix: `bug_log:` });
      for (const key of keys.keys) {
        const logData = await env.XMSBRA_KV.get(key.name);
        if (logData) {
          const log = JSON.parse(logData);
          if (log.sessionId === sessionId) {
            await env.XMSBRA_KV.delete(key.name);
          }
        }
      }

      return {
        success: true,
        message: 'Session cleaned up successfully'
      };

    } catch (error) {
      console.error('Cleanup session error:', error);
      return {
        success: false,
        error: 'Failed to cleanup session'
      };
    }
  },

  // Get WhatsApp channel info (adapted from original function)
  async getWhatsAppChannelInfo(env, channelLink) {
    try {
      // Validate channel link
      if (!channelLink.includes('https://whatsapp.com/channel/')) {
        return {
          success: false,
          error: 'Invalid WhatsApp channel link'
        };
      }

      // Extract channel ID from link
      const channelId = channelLink.split('/').pop();
      
      // Simulate channel info retrieval
      const channelInfo = {
        id: channelId,
        name: 'Sample Channel',
        description: 'This is a sample channel description',
        subscribers: Math.floor(Math.random() * 10000),
        verified: Math.random() > 0.5,
        createdAt: new Date(Date.now() - Math.random() * 31536000000).toISOString(), // Random date within last year
        category: 'General',
        link: channelLink,
        avatar: null,
        isActive: true,
        lastPost: new Date(Date.now() - Math.random() * 86400000).toISOString() // Random date within last day
      };

      return {
        success: true,
        channelInfo
      };

    } catch (error) {
      console.error('Get channel info error:', error);
      return {
        success: false,
        error: 'Failed to get channel information'
      };
    }
  },

  // Validate bot token (for Telegram bot integration)
  async validateBotToken(env, token) {
    try {
      // Basic token format validation
      if (!token || typeof token !== 'string') {
        return {
          success: false,
          error: 'Invalid token format'
        };
      }

      // Check if token matches expected format (bot_id:token)
      const tokenParts = token.split(':');
      if (tokenParts.length !== 2) {
        return {
          success: false,
          error: 'Invalid token format'
        };
      }

      const [botId, botToken] = tokenParts;
      
      // Validate bot ID (should be numeric)
      if (!/^\d+$/.test(botId)) {
        return {
          success: false,
          error: 'Invalid bot ID'
        };
      }

      // Simulate token validation
      const isValid = botToken.length >= 35; // Telegram bot tokens are typically 45+ characters
      
      if (isValid) {
        return {
          success: true,
          tokenInfo: {
            botId,
            isValid: true,
            botName: `Bot_${botId}`,
            username: `xmsbra_bot_${botId}`,
            canJoinGroups: true,
            canReadAllGroupMessages: false,
            supportsInlineQueries: false,
            validatedAt: new Date().toISOString()
          }
        };
      } else {
        return {
          success: false,
          error: 'Invalid token'
        };
      }

    } catch (error) {
      console.error('Validate bot token error:', error);
      return {
        success: false,
        error: 'Failed to validate bot token'
      };
    }
  },

  // Helper functions
  async getSessionData(env, sessionId) {
    try {
      const data = await env.XMSBRA_KV.get(`wa_session:${sessionId}`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Get session data error:', error);
      return null;
    }
  },

  async generateQRCode(sessionId) {
    // Generate a simulated QR code data
    const qrData = `xmsbra_session_${sessionId}_${Date.now()}`;
    return `data:image/png;base64,${btoa(qrData)}`;
  },

  // Bug payload generators (adapted from original index.js)
  generateXataDelayPayload() {
    return {
      type: 'xata_force_delay',
      payload: '🔥'.repeat(1000), // Large emoji payload to cause delay
      timestamp: Date.now()
    };
  },

  generateForceClosePayload() {
    return {
      type: 'force_close',
      payload: '\u0000'.repeat(500), // Null characters to cause app crash
      timestamp: Date.now()
    };
  },

  generateCrashTargetPayload() {
    return {
      type: 'crash_target',
      payload: {
        text: '💥'.repeat(2000), // Large payload
        mentions: Array(100).fill('@everyone'), // Excessive mentions
        timestamp: Date.now()
      }
    };
  },

  // Format runtime (adapted from original function)
  formatRuntime(seconds) {
    const days = Math.floor(seconds / (3600 * 24));
    const hours = Math.floor((seconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    return `${days}d ${hours}h ${minutes}m ${secs}s`;
  },

  // Get current date (adapted from original function)
  getCurrentDate() {
    const now = new Date();
    const options = { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      timeZone: 'Asia/Jakarta'
    };
    return now.toLocaleDateString('id-ID', options);
  },

  // Get speed calculation
  getSpeed() {
    return Math.floor(Math.random() * 100) + 50; // Random speed between 50-150
  }
};

