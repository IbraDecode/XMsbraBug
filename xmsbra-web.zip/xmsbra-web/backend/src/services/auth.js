// XMSBRA API - Authentication Service
import { SignJWT, jwtVerify } from 'jose';

export const authService = {
  // Validate access token against environment variables
  async validateAccessToken(env, token) {
    const tokens = {
      [env.OWNER_TOKEN]: 'owner',
      [env.ADMIN_TOKEN]: 'admin', 
      [env.PREMIUM_TOKEN]: 'premium'
    };
    
    return tokens[token] || null;
  },

  // Generate access token for a role
  async generateAccessToken(env, role, description = '') {
    const timestamp = Date.now();
    const randomString = Math.random().toString(36).substring(2, 15);
    return `xmsbra_${role}_${timestamp}_${randomString}`;
  },

  // Generate JWT token
  async generateJWT(env, payload) {
    const secret = new TextEncoder().encode(env.JWT_SECRET);
    
    const jwt = await new SignJWT(payload)
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuedAt()
      .setExpirationTime('24h')
      .setSubject(payload.token || 'unknown')
      .sign(secret);
    
    return jwt;
  },

  // Verify JWT token
  async verifyJWT(env, token) {
    try {
      const secret = new TextEncoder().encode(env.JWT_SECRET);
      const { payload } = await jwtVerify(token, secret);
      return payload;
    } catch (error) {
      console.error('JWT verification failed:', error);
      return null;
    }
  },

  // Get role permissions
  getRolePermissions(role) {
    const permissions = {
      owner: [
        'add_sender', 'list_sender', 'delete_sender',
        'bug_menu', 'force_close', 'crash_target',
        'user_management', 'premium_control', 'system_config',
        'cooldown_settings', 'token_validator', 'wa_channel_info',
        'generate_tokens', 'view_logs', 'manage_system'
      ],
      admin: [
        'add_sender', 'list_sender',
        'bug_menu', 'force_close',
        'wa_channel_info', 'view_logs'
      ],
      premium: [
        'add_sender', 'list_sender',
        'wa_channel_info'
      ]
    };
    
    return permissions[role] || [];
  },

  // Check if user has permission
  hasPermission(userRole, permission) {
    const permissions = this.getRolePermissions(userRole);
    return permissions.includes(permission);
  },

  // Generate session ID
  generateSessionId() {
    return `session_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
  },

  // Hash password (for future use if needed)
  async hashPassword(password) {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hash = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hash))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  },

  // Verify password (for future use if needed)
  async verifyPassword(password, hash) {
    const hashedPassword = await this.hashPassword(password);
    return hashedPassword === hash;
  },

  // Generate API key
  generateApiKey() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 32; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  },

  // Rate limiting check
  async checkRateLimit(env, identifier, limit = 100, window = 3600) {
    const key = `rate_limit:${identifier}`;
    const now = Math.floor(Date.now() / 1000);
    const windowStart = now - window;
    
    try {
      // Get current count from KV
      const currentData = await env.XMSBRA_KV.get(key);
      let requests = currentData ? JSON.parse(currentData) : [];
      
      // Remove old requests outside the window
      requests = requests.filter(timestamp => timestamp > windowStart);
      
      // Check if limit exceeded
      if (requests.length >= limit) {
        return false;
      }
      
      // Add current request
      requests.push(now);
      
      // Store updated requests
      await env.XMSBRA_KV.put(key, JSON.stringify(requests), {
        expirationTtl: window
      });
      
      return true;
    } catch (error) {
      console.error('Rate limit check failed:', error);
      return true; // Allow request if rate limiting fails
    }
  },

  // Get user info from session
  async getUserFromSession(env, sessionId) {
    try {
      const sessionData = await env.XMSBRA_KV.get(`session:${sessionId}`);
      if (!sessionData) return null;
      
      const session = JSON.parse(sessionData);
      if (session.expiresAt < Date.now()) {
        // Session expired, clean up
        await env.XMSBRA_KV.delete(`session:${sessionId}`);
        return null;
      }
      
      return session.user;
    } catch (error) {
      console.error('Get user from session failed:', error);
      return null;
    }
  },

  // Validate request origin
  validateOrigin(request, allowedOrigins = ['*']) {
    if (allowedOrigins.includes('*')) return true;
    
    const origin = request.headers.get('Origin');
    return allowedOrigins.includes(origin);
  },

  // Generate CSRF token
  generateCSRFToken() {
    return this.generateApiKey();
  },

  // Validate CSRF token
  async validateCSRFToken(env, token, sessionId) {
    try {
      const storedToken = await env.XMSBRA_KV.get(`csrf:${sessionId}`);
      return storedToken === token;
    } catch (error) {
      console.error('CSRF validation failed:', error);
      return false;
    }
  },

  // Store CSRF token
  async storeCSRFToken(env, token, sessionId) {
    try {
      await env.XMSBRA_KV.put(`csrf:${sessionId}`, token, {
        expirationTtl: 3600 // 1 hour
      });
    } catch (error) {
      console.error('CSRF token storage failed:', error);
    }
  }
};

