// XMSBRA API - KV Storage Service

export const kvService = {
  // Session management
  async setSession(env, sessionId, sessionData) {
    try {
      await env.XMSBRA_KV.put(
        `session:${sessionId}`, 
        JSON.stringify(sessionData),
        { expirationTtl: 86400 } // 24 hours
      );
    } catch (error) {
      console.error('Set session failed:', error);
      throw error;
    }
  },

  async getSession(env, sessionId) {
    try {
      const data = await env.XMSBRA_KV.get(`session:${sessionId}`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Get session failed:', error);
      return null;
    }
  },

  async deleteSession(env, sessionId) {
    try {
      await env.XMSBRA_KV.delete(`session:${sessionId}`);
    } catch (error) {
      console.error('Delete session failed:', error);
    }
  },

  // Access token management
  async storeAccessToken(env, token, tokenData) {
    try {
      await env.XMSBRA_KV.put(
        `access_token:${token}`,
        JSON.stringify(tokenData)
      );
      
      // Also store in tokens list for easy retrieval
      const tokensList = await this.getTokensList(env);
      tokensList.push({
        token,
        ...tokenData
      });
      
      await env.XMSBRA_KV.put(
        'access_tokens_list',
        JSON.stringify(tokensList)
      );
    } catch (error) {
      console.error('Store access token failed:', error);
      throw error;
    }
  },

  async getAccessToken(env, token) {
    try {
      const data = await env.XMSBRA_KV.get(`access_token:${token}`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Get access token failed:', error);
      return null;
    }
  },

  async getAllAccessTokens(env) {
    try {
      return await this.getTokensList(env);
    } catch (error) {
      console.error('Get all access tokens failed:', error);
      return [];
    }
  },

  async getTokensList(env) {
    try {
      const data = await env.XMSBRA_KV.get('access_tokens_list');
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Get tokens list failed:', error);
      return [];
    }
  },

  async revokeAccessToken(env, token) {
    try {
      // Mark token as revoked
      const tokenData = await this.getAccessToken(env, token);
      if (tokenData) {
        tokenData.isActive = false;
        tokenData.revokedAt = new Date().toISOString();
        await env.XMSBRA_KV.put(
          `access_token:${token}`,
          JSON.stringify(tokenData)
        );
      }
      
      // Update tokens list
      const tokensList = await this.getTokensList(env);
      const updatedList = tokensList.map(t => 
        t.token === token 
          ? { ...t, isActive: false, revokedAt: new Date().toISOString() }
          : t
      );
      
      await env.XMSBRA_KV.put(
        'access_tokens_list',
        JSON.stringify(updatedList)
      );
    } catch (error) {
      console.error('Revoke access token failed:', error);
      throw error;
    }
  },

  // WhatsApp sender management
  async storeSender(env, sessionId, senderData) {
    try {
      await env.XMSBRA_KV.put(
        `sender:${sessionId}`,
        JSON.stringify(senderData)
      );
      
      // Update senders list
      const sendersList = await this.getSendersList(env);
      const existingIndex = sendersList.findIndex(s => s.sessionId === sessionId);
      
      if (existingIndex >= 0) {
        sendersList[existingIndex] = { sessionId, ...senderData };
      } else {
        sendersList.push({ sessionId, ...senderData });
      }
      
      await env.XMSBRA_KV.put(
        'senders_list',
        JSON.stringify(sendersList)
      );
    } catch (error) {
      console.error('Store sender failed:', error);
      throw error;
    }
  },

  async getSender(env, sessionId) {
    try {
      const data = await env.XMSBRA_KV.get(`sender:${sessionId}`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Get sender failed:', error);
      return null;
    }
  },

  async getAllSenders(env) {
    try {
      return await this.getSendersList(env);
    } catch (error) {
      console.error('Get all senders failed:', error);
      return [];
    }
  },

  async getSendersList(env) {
    try {
      const data = await env.XMSBRA_KV.get('senders_list');
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Get senders list failed:', error);
      return [];
    }
  },

  async deleteSender(env, sessionId) {
    try {
      await env.XMSBRA_KV.delete(`sender:${sessionId}`);
      
      // Update senders list
      const sendersList = await this.getSendersList(env);
      const updatedList = sendersList.filter(s => s.sessionId !== sessionId);
      
      await env.XMSBRA_KV.put(
        'senders_list',
        JSON.stringify(updatedList)
      );
    } catch (error) {
      console.error('Delete sender failed:', error);
      throw error;
    }
  },

  // Cooldown management
  async setCooldown(env, userId, cooldownData) {
    try {
      await env.XMSBRA_KV.put(
        `cooldown:${userId}`,
        JSON.stringify(cooldownData),
        { expirationTtl: Math.ceil(cooldownData.duration / 1000) }
      );
    } catch (error) {
      console.error('Set cooldown failed:', error);
      throw error;
    }
  },

  async getCooldown(env, userId) {
    try {
      const data = await env.XMSBRA_KV.get(`cooldown:${userId}`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Get cooldown failed:', error);
      return null;
    }
  },

  async checkCooldown(env, userId) {
    try {
      const cooldown = await this.getCooldown(env, userId);
      if (!cooldown) return false;
      
      const now = Date.now();
      return now < (cooldown.startTime + cooldown.duration);
    } catch (error) {
      console.error('Check cooldown failed:', error);
      return false;
    }
  },

  // System configuration
  async getConfig(env) {
    try {
      const data = await env.XMSBRA_KV.get('system_config');
      return data ? JSON.parse(data) : {
        botName: 'XMSBRA Bot',
        maxSessions: 10,
        autoRestart: true,
        defaultCooldown: 300000, // 5 minutes
        rateLimit: {
          requests: 100,
          window: 3600 // 1 hour
        }
      };
    } catch (error) {
      console.error('Get config failed:', error);
      return {};
    }
  },

  async setConfig(env, config) {
    try {
      await env.XMSBRA_KV.put(
        'system_config',
        JSON.stringify(config)
      );
    } catch (error) {
      console.error('Set config failed:', error);
      throw error;
    }
  },

  // Activity logging
  async logActivity(env, activityData) {
    try {
      const logId = `log_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
      
      await env.XMSBRA_KV.put(
        `activity:${logId}`,
        JSON.stringify(activityData),
        { expirationTtl: 2592000 } // 30 days
      );
      
      // Update activity logs list (keep last 1000 entries)
      const logsList = await this.getActivityLogs(env, 1000);
      logsList.unshift({ logId, ...activityData });
      
      // Keep only last 1000 entries
      if (logsList.length > 1000) {
        logsList.splice(1000);
      }
      
      await env.XMSBRA_KV.put(
        'activity_logs_list',
        JSON.stringify(logsList)
      );
    } catch (error) {
      console.error('Log activity failed:', error);
    }
  },

  async getActivityLogs(env, limit = 50) {
    try {
      const data = await env.XMSBRA_KV.get('activity_logs_list');
      const logs = data ? JSON.parse(data) : [];
      return logs.slice(0, limit);
    } catch (error) {
      console.error('Get activity logs failed:', error);
      return [];
    }
  },

  // Statistics
  async updateStats(env, statType, increment = 1) {
    try {
      const statsData = await this.getStats(env);
      statsData[statType] = (statsData[statType] || 0) + increment;
      statsData.lastUpdated = new Date().toISOString();
      
      await env.XMSBRA_KV.put(
        'bot_stats',
        JSON.stringify(statsData)
      );
    } catch (error) {
      console.error('Update stats failed:', error);
    }
  },

  async getStats(env) {
    try {
      const data = await env.XMSBRA_KV.get('bot_stats');
      return data ? JSON.parse(data) : {
        totalUsers: 0,
        activeSenders: 0,
        premiumUsers: 0,
        bugsSent: 0,
        messagesSent: 0,
        activeSessions: 0,
        lastRestart: new Date().toISOString(),
        lastUpdated: new Date().toISOString()
      };
    } catch (error) {
      console.error('Get stats failed:', error);
      return {};
    }
  },

  // Premium user management
  async setPremiumUser(env, userId, premiumData) {
    try {
      await env.XMSBRA_KV.put(
        `premium:${userId}`,
        JSON.stringify(premiumData)
      );
      
      // Update premium users list
      const premiumList = await this.getPremiumUsersList(env);
      const existingIndex = premiumList.findIndex(p => p.userId === userId);
      
      if (existingIndex >= 0) {
        premiumList[existingIndex] = { userId, ...premiumData };
      } else {
        premiumList.push({ userId, ...premiumData });
      }
      
      await env.XMSBRA_KV.put(
        'premium_users_list',
        JSON.stringify(premiumList)
      );
    } catch (error) {
      console.error('Set premium user failed:', error);
      throw error;
    }
  },

  async getPremiumUser(env, userId) {
    try {
      const data = await env.XMSBRA_KV.get(`premium:${userId}`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Get premium user failed:', error);
      return null;
    }
  },

  async getAllPremiumUsers(env) {
    try {
      return await this.getPremiumUsersList(env);
    } catch (error) {
      console.error('Get all premium users failed:', error);
      return [];
    }
  },

  async getPremiumUsersList(env) {
    try {
      const data = await env.XMSBRA_KV.get('premium_users_list');
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Get premium users list failed:', error);
      return [];
    }
  },

  async removePremiumUser(env, userId) {
    try {
      await env.XMSBRA_KV.delete(`premium:${userId}`);
      
      // Update premium users list
      const premiumList = await this.getPremiumUsersList(env);
      const updatedList = premiumList.filter(p => p.userId !== userId);
      
      await env.XMSBRA_KV.put(
        'premium_users_list',
        JSON.stringify(updatedList)
      );
    } catch (error) {
      console.error('Remove premium user failed:', error);
      throw error;
    }
  },

  // Cache management
  async setCache(env, key, data, ttl = 3600) {
    try {
      await env.XMSBRA_KV.put(
        `cache:${key}`,
        JSON.stringify(data),
        { expirationTtl: ttl }
      );
    } catch (error) {
      console.error('Set cache failed:', error);
    }
  },

  async getCache(env, key) {
    try {
      const data = await env.XMSBRA_KV.get(`cache:${key}`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Get cache failed:', error);
      return null;
    }
  },

  async deleteCache(env, key) {
    try {
      await env.XMSBRA_KV.delete(`cache:${key}`);
    } catch (error) {
      console.error('Delete cache failed:', error);
    }
  },

  // Cleanup expired data
  async cleanup(env) {
    try {
      // This would be called periodically to clean up expired data
      // KV automatically handles TTL expiration, but we can clean up lists
      
      const now = Date.now();
      
      // Clean up expired sessions from lists
      const sendersList = await this.getSendersList(env);
      const activeSenders = [];
      
      for (const sender of sendersList) {
        const senderData = await this.getSender(env, sender.sessionId);
        if (senderData && senderData.lastActive && 
            (now - new Date(senderData.lastActive).getTime()) < 86400000) { // 24 hours
          activeSenders.push(sender);
        }
      }
      
      if (activeSenders.length !== sendersList.length) {
        await env.XMSBRA_KV.put(
          'senders_list',
          JSON.stringify(activeSenders)
        );
      }
      
      // Clean up expired premium users
      const premiumList = await this.getPremiumUsersList(env);
      const activePremium = premiumList.filter(p => 
        !p.expiresAt || new Date(p.expiresAt).getTime() > now
      );
      
      if (activePremium.length !== premiumList.length) {
        await env.XMSBRA_KV.put(
          'premium_users_list',
          JSON.stringify(activePremium)
        );
      }
      
    } catch (error) {
      console.error('Cleanup failed:', error);
    }
  }
};

