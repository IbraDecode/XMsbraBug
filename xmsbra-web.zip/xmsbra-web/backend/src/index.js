// XMSBRA Cloudflare Workers API
import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { logger } from 'hono/logger';
import { prettyJSON } from 'hono/pretty-json';

// Import routes
import authRoutes from './routes/auth.js';
import botRoutes from './routes/bot.js';
import senderRoutes from './routes/sender.js';
import bugRoutes from './routes/bug.js';
import userRoutes from './routes/user.js';
import premiumRoutes from './routes/premium.js';
import configRoutes from './routes/config.js';
import cooldownRoutes from './routes/cooldown.js';
import toolsRoutes from './routes/tools.js';
import dashboardRoutes from './routes/dashboard.js';
import logsRoutes from './routes/logs.js';

// Import middleware
import { authMiddleware } from './middleware/auth.js';
import { errorHandler } from './middleware/error.js';
import { rateLimiter } from './middleware/rateLimit.js';

const app = new Hono();

// Global middleware
app.use('*', logger());
app.use('*', prettyJSON());

// CORS middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
  exposeHeaders: ['Content-Length', 'X-Kuma-Revision'],
  maxAge: 600,
  credentials: true,
}));

// Rate limiting middleware
app.use('*', rateLimiter);

// Health check endpoint
app.get('/', (c) => {
  return c.json({
    name: 'XMSBRA API',
    version: '1.0.0',
    status: 'healthy',
    timestamp: new Date().toISOString(),
    environment: c.env.ENVIRONMENT || 'development'
  });
});

app.get('/health', (c) => {
  return c.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: Date.now(),
    memory: {
      used: process.memoryUsage?.()?.heapUsed || 0,
      total: process.memoryUsage?.()?.heapTotal || 0
    }
  });
});

// API routes
app.route('/auth', authRoutes);
app.route('/bot', botRoutes);
app.route('/sender', senderRoutes);
app.route('/bug', bugRoutes);
app.route('/users', userRoutes);
app.route('/premium', premiumRoutes);
app.route('/config', configRoutes);
app.route('/cooldown', cooldownRoutes);
app.route('/tools', toolsRoutes);
app.route('/dashboard', dashboardRoutes);
app.route('/logs', logsRoutes);

// Protected routes middleware
app.use('/users/*', authMiddleware);
app.use('/premium/*', authMiddleware);
app.use('/config/*', authMiddleware);
app.use('/cooldown/*', authMiddleware);
app.use('/logs/*', authMiddleware);

// 404 handler
app.notFound((c) => {
  return c.json({
    error: 'Not Found',
    message: 'The requested endpoint does not exist',
    path: c.req.path,
    method: c.req.method
  }, 404);
});

// Error handler
app.onError(errorHandler);

// Export for Cloudflare Workers
export default {
  async fetch(request, env, ctx) {
    // Add environment to context
    return app.fetch(request, { ...env, ctx });
  }
};

