// XMSBRA Utility Functions

// Toast notification system
function showToast(type, title, message, duration = CONFIG.TOAST_DURATION) {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    toast.innerHTML = `
        <div class="toast-header">
            <span class="toast-title">${title}</span>
            <button class="toast-close" onclick="this.parentElement.parentElement.remove()">&times;</button>
        </div>
        <div class="toast-message">${message}</div>
    `;
    
    container.appendChild(toast);
    
    // Auto remove after duration
    setTimeout(() => {
        if (toast.parentElement) {
            toast.remove();
        }
    }, duration);
}

// Format runtime display
function formatRuntime(seconds) {
    const days = Math.floor(seconds / (3600 * 24));
    const hours = Math.floor((seconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    return `${days}d ${hours}h ${minutes}m ${secs}s`;
}

// Format date and time
function formatDateTime(date) {
    if (!date) return 'N/A';
    
    const d = new Date(date);
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    
    return d.toLocaleDateString('id-ID', options);
}

// Format current date
function getCurrentDate() {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    };
    return now.toLocaleDateString('id-ID', options);
}

// Format phone number
function formatPhoneNumber(phone) {
    if (!phone) return '';
    
    // Remove non-digits
    const cleaned = phone.replace(/\D/g, '');
    
    // Add country code if not present
    if (!cleaned.startsWith('62')) {
        return '62' + cleaned.replace(/^0/, '');
    }
    
    return cleaned;
}

// Validate phone number
function isValidPhoneNumber(phone) {
    const cleaned = phone.replace(/\D/g, '');
    return cleaned.length >= 10 && cleaned.length <= 15;
}

// Validate WhatsApp channel link
function isValidWhatsAppChannelLink(link) {
    return link.includes('https://whatsapp.com/channel/');
}

// Generate random ID
function generateId(length = 8) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

// Debounce function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Throttle function
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Copy to clipboard
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        showToast('success', 'Copied', 'Text copied to clipboard');
        return true;
    } catch (error) {
        console.error('Failed to copy:', error);
        showToast('error', 'Error', 'Failed to copy to clipboard');
        return false;
    }
}

// Download as file
function downloadAsFile(content, filename, contentType = 'text/plain') {
    const blob = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

// Format file size
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Get status color class
function getStatusColor(status) {
    const statusColors = {
        'online': 'success',
        'active': 'success',
        'connected': 'success',
        'offline': 'danger',
        'inactive': 'danger',
        'disconnected': 'danger',
        'connecting': 'warning',
        'pairing': 'warning',
        'pending': 'warning',
        'error': 'danger',
        'failed': 'danger'
    };
    
    return statusColors[status.toLowerCase()] || 'secondary';
}

// Format status text
function formatStatus(status) {
    if (!status) return 'Unknown';
    
    return status.charAt(0).toUpperCase() + status.slice(1).toLowerCase();
}

// Parse cooldown time string
function parseCooldownTime(timeString) {
    const match = timeString.match(/(\d+)([smh])/);
    if (!match) return null;
    
    const [_, value, unit] = match;
    const numValue = parseInt(value);
    
    switch (unit) {
        case 's': return numValue * 1000;
        case 'm': return numValue * 60 * 1000;
        case 'h': return numValue * 60 * 60 * 1000;
        default: return null;
    }
}

// Format cooldown time
function formatCooldownTime(milliseconds) {
    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    if (hours > 0) {
        return `${hours}h ${minutes % 60}m`;
    } else if (minutes > 0) {
        return `${minutes}m ${seconds % 60}s`;
    } else {
        return `${seconds}s`;
    }
}

// Check if user has permission
function hasPermission(permission) {
    return window.authManager && window.authManager.hasPermission(permission);
}

// Get user role
function getUserRole() {
    return window.authManager ? window.authManager.getUserRole() : 'guest';
}

// Show loading state
function showLoading(element, text = 'Loading...') {
    if (typeof element === 'string') {
        element = document.getElementById(element);
    }
    
    if (element) {
        element.innerHTML = `
            <div class="loading">
                <div class="spinner"></div>
                <span style="margin-left: 1rem;">${text}</span>
            </div>
        `;
    }
}

// Hide loading state
function hideLoading(element) {
    if (typeof element === 'string') {
        element = document.getElementById(element);
    }
    
    if (element) {
        element.innerHTML = '';
    }
}

// Escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Sanitize input
function sanitizeInput(input) {
    if (typeof input !== 'string') return input;
    
    return input
        .replace(/[<>]/g, '') // Remove < and >
        .trim(); // Remove leading/trailing whitespace
}

// Validate form data
function validateForm(formData, rules) {
    const errors = {};
    
    for (const [field, rule] of Object.entries(rules)) {
        const value = formData[field];
        
        if (rule.required && (!value || value.trim() === '')) {
            errors[field] = `${field} is required`;
            continue;
        }
        
        if (value && rule.minLength && value.length < rule.minLength) {
            errors[field] = `${field} must be at least ${rule.minLength} characters`;
            continue;
        }
        
        if (value && rule.maxLength && value.length > rule.maxLength) {
            errors[field] = `${field} must be no more than ${rule.maxLength} characters`;
            continue;
        }
        
        if (value && rule.pattern && !rule.pattern.test(value)) {
            errors[field] = rule.message || `${field} format is invalid`;
            continue;
        }
        
        if (value && rule.custom && !rule.custom(value)) {
            errors[field] = rule.message || `${field} is invalid`;
        }
    }
    
    return {
        isValid: Object.keys(errors).length === 0,
        errors
    };
}

// Show form errors
function showFormErrors(errors) {
    // Clear previous errors
    document.querySelectorAll('.form-error').forEach(el => el.remove());
    
    for (const [field, message] of Object.entries(errors)) {
        const input = document.querySelector(`[name="${field}"]`);
        if (input) {
            const error = document.createElement('div');
            error.className = 'form-error';
            error.style.color = 'var(--danger-color)';
            error.style.fontSize = '0.8rem';
            error.style.marginTop = '0.25rem';
            error.textContent = message;
            
            input.parentElement.appendChild(error);
            input.style.borderColor = 'var(--danger-color)';
        }
    }
}

// Clear form errors
function clearFormErrors() {
    document.querySelectorAll('.form-error').forEach(el => el.remove());
    document.querySelectorAll('input, textarea, select').forEach(el => {
        el.style.borderColor = '';
    });
}

// Auto-update time displays
function startTimeUpdates() {
    const updateTime = () => {
        const timeElement = document.getElementById('currentTime');
        if (timeElement) {
            timeElement.textContent = new Date().toLocaleTimeString('id-ID');
        }
    };
    
    updateTime();
    setInterval(updateTime, 1000);
}

// Auto-update runtime display
function startRuntimeUpdates() {
    let startTime = Math.floor(Date.now() / 1000);
    
    const updateRuntime = () => {
        const runtimeElement = document.getElementById('botRuntime');
        if (runtimeElement) {
            const now = Math.floor(Date.now() / 1000);
            const runtime = now - startTime;
            runtimeElement.textContent = `Runtime: ${formatRuntime(runtime)}`;
        }
    };
    
    updateRuntime();
    setInterval(updateRuntime, 1000);
}

// Initialize utility functions
document.addEventListener('DOMContentLoaded', () => {
    startTimeUpdates();
    startRuntimeUpdates();
});

// Export functions to global scope
window.showToast = showToast;
window.formatRuntime = formatRuntime;
window.formatDateTime = formatDateTime;
window.getCurrentDate = getCurrentDate;
window.formatPhoneNumber = formatPhoneNumber;
window.isValidPhoneNumber = isValidPhoneNumber;
window.isValidWhatsAppChannelLink = isValidWhatsAppChannelLink;
window.generateId = generateId;
window.debounce = debounce;
window.throttle = throttle;
window.copyToClipboard = copyToClipboard;
window.downloadAsFile = downloadAsFile;
window.formatFileSize = formatFileSize;
window.getStatusColor = getStatusColor;
window.formatStatus = formatStatus;
window.parseCooldownTime = parseCooldownTime;
window.formatCooldownTime = formatCooldownTime;
window.hasPermission = hasPermission;
window.getUserRole = getUserRole;
window.showLoading = showLoading;
window.hideLoading = hideLoading;
window.escapeHtml = escapeHtml;
window.sanitizeInput = sanitizeInput;
window.validateForm = validateForm;
window.showFormErrors = showFormErrors;
window.clearFormErrors = clearFormErrors;

