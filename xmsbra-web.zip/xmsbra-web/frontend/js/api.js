// XMSBRA API Client

class APIClient {
    constructor() {
        this.baseURL = CONFIG.API_BASE_URL;
    }

    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        };

        // Add auth headers if user is authenticated
        if (window.authManager && window.authManager.isAuthenticated) {
            config.headers = {
                ...config.headers,
                ...window.authManager.getAuthHeaders()
            };
        }

        try {
            const response = await fetch(url, config);
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || `HTTP ${response.status}`);
            }

            return data;
        } catch (error) {
            console.error(`API request failed: ${endpoint}`, error);
            throw error;
        }
    }

    // Authentication endpoints
    async login(username, password) {
        return this.request('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
    }

    async validateToken() {
        return this.request('/auth/validate');
    }

    async refreshToken() {
        return this.request('/auth/refresh', { method: 'POST' });
    }

    // Bot status endpoints
    async getBotStatus() {
        return this.request('/bot/status');
    }

    async getBotRuntime() {
        return this.request('/bot/runtime');
    }

    async getBotStats() {
        return this.request('/bot/stats');
    }

    // Sender management endpoints
    async addSender(phoneNumber) {
        return this.request('/sender/add', {
            method: 'POST',
            body: JSON.stringify({ phoneNumber })
        });
    }

    async getSenders() {
        return this.request('/sender/list');
    }

    async deleteSender(sessionId) {
        return this.request(`/sender/delete/${sessionId}`, {
            method: 'DELETE'
        });
    }

    async getSenderStatus(sessionId) {
        return this.request(`/sender/status/${sessionId}`);
    }

    async connectSender(sessionId) {
        return this.request(`/sender/connect/${sessionId}`, {
            method: 'POST'
        });
    }

    async disconnectSender(sessionId) {
        return this.request(`/sender/disconnect/${sessionId}`, {
            method: 'POST'
        });
    }

    // Bug menu endpoints
    async sendXataDelay(target, sessionId) {
        return this.request('/bug/xata-delay', {
            method: 'POST',
            body: JSON.stringify({ target, sessionId })
        });
    }

    async sendForceClose(target, sessionId) {
        return this.request('/bug/force-close', {
            method: 'POST',
            body: JSON.stringify({ target, sessionId })
        });
    }

    async sendCrashTarget(target, sessionId) {
        return this.request('/bug/crash-target', {
            method: 'POST',
            body: JSON.stringify({ target, sessionId })
        });
    }

    // User management endpoints (owner only)
    async getUsers() {
        return this.request('/users');
    }

    async createUser(userData) {
        return this.request('/users', {
            method: 'POST',
            body: JSON.stringify(userData)
        });
    }

    async updateUser(userId, userData) {
        return this.request(`/users/${userId}`, {
            method: 'PUT',
            body: JSON.stringify(userData)
        });
    }

    async deleteUser(userId) {
        return this.request(`/users/${userId}`, {
            method: 'DELETE'
        });
    }

    // Premium management endpoints
    async getPremiumUsers() {
        return this.request('/premium/users');
    }

    async addPremiumUser(userId, expiresAt) {
        return this.request('/premium/add', {
            method: 'POST',
            body: JSON.stringify({ userId, expiresAt })
        });
    }

    async removePremiumUser(userId) {
        return this.request(`/premium/remove/${userId}`, {
            method: 'DELETE'
        });
    }

    async extendPremium(userId, days) {
        return this.request('/premium/extend', {
            method: 'POST',
            body: JSON.stringify({ userId, days })
        });
    }

    // System configuration endpoints
    async getSystemConfig() {
        return this.request('/config');
    }

    async updateSystemConfig(config) {
        return this.request('/config', {
            method: 'PUT',
            body: JSON.stringify(config)
        });
    }

    // Cooldown management endpoints
    async getCooldownSettings() {
        return this.request('/cooldown/settings');
    }

    async setCooldown(timeString) {
        return this.request('/cooldown/set', {
            method: 'POST',
            body: JSON.stringify({ time: timeString })
        });
    }

    async checkCooldown(userId) {
        return this.request(`/cooldown/check/${userId}`);
    }

    // WhatsApp channel info endpoint
    async getWhatsAppChannelInfo(channelLink) {
        return this.request('/tools/wa-channel-info', {
            method: 'POST',
            body: JSON.stringify({ link: channelLink })
        });
    }

    // Token validation endpoint
    async validateBotToken(token) {
        return this.request('/tools/validate-token', {
            method: 'POST',
            body: JSON.stringify({ token })
        });
    }

    // Activity logs endpoint
    async getActivityLogs(limit = 50) {
        return this.request(`/logs/activity?limit=${limit}`);
    }

    // Dashboard overview endpoint
    async getDashboardOverview() {
        return this.request('/dashboard/overview');
    }
}

// Utility functions for API calls with error handling
class APIUtils {
    static async handleAPICall(apiCall, successMessage = null, errorMessage = null) {
        try {
            const result = await apiCall();
            
            if (successMessage) {
                window.showToast('success', 'Success', successMessage);
            }
            
            return { success: true, data: result };
        } catch (error) {
            const message = errorMessage || error.message || 'An error occurred';
            window.showToast('error', 'Error', message);
            
            return { success: false, error: message };
        }
    }

    static async handleFormSubmit(form, apiCall, successMessage = null) {
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        
        // Show loading state
        submitBtn.textContent = 'Processing...';
        submitBtn.disabled = true;
        
        try {
            const result = await this.handleAPICall(apiCall, successMessage);
            
            if (result.success) {
                form.reset();
            }
            
            return result;
        } finally {
            // Reset button state
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    }

    static formatError(error) {
        if (typeof error === 'string') return error;
        if (error.message) return error.message;
        return 'An unknown error occurred';
    }

    static isNetworkError(error) {
        return error.message.includes('fetch') || 
               error.message.includes('network') ||
               error.message.includes('Failed to fetch');
    }

    static handleNetworkError() {
        window.showToast('error', 'Network Error', 'Please check your internet connection');
    }
}

// Initialize API client
const apiClient = new APIClient();

// Export for use in other modules
window.apiClient = apiClient;
window.APIUtils = APIUtils;

