// XMSBRA Page Management Module

class PageManager {
    constructor() {
        this.pageContentElement = document.getElementById("pageContent");
        this.currentPage = null;
    }

    async loadPage(pageName) {
        if (this.currentPage === pageName) return; // Prevent reloading same page

        this.currentPage = pageName;
        window.showLoading(this.pageContentElement, `Loading ${pageName} page...`);

        // Update active navigation link
        document.querySelectorAll(".nav-link").forEach(link => {
            if (link.getAttribute("data-page") === pageName) {
                link.classList.add("active");
            } else {
                link.classList.remove("active");
            }
        });

        let content = "";
        switch (pageName) {
            case "overview":
                content = await this.getOverviewPage();
                break;
            case "bot-status":
                content = await this.getBotStatusPage();
                break;
            case "add-sender":
                content = await this.getAddSenderPage();
                break;
            case "list-sender":
                content = await this.getListSenderPage();
                break;
            case "sender-status":
                content = await this.getSenderStatusPage();
                break;
            case "xata-delay":
                content = await this.getXataDelayPage();
                break;
            case "force-close":
                content = await this.getForceClosePage();
                break;
            case "crash-target":
                content = await this.getCrashTargetPage();
                break;
            case "user-management":
                content = await this.getUserManagementPage();
                break;
            case "premium-control":
                content = await this.getPremiumControlPage();
                break;
            case "system-config":
                content = await this.getSystemConfigPage();
                break;
            case "cooldown-settings":
                content = await this.getCooldownSettingsPage();
                break;
            case "wa-channel-info":
                content = await this.getWAChannelInfoPage();
                break;
            case "token-validator":
                content = await this.getTokenValidatorPage();
                break;
            default:
                content = `<h2>Page Not Found</h2><p>The page ${pageName} does not exist.</p>`;
                break;
        }

        this.pageContentElement.innerHTML = content;
        window.hideLoading(this.pageContentElement);
        this.attachPageSpecificListeners(pageName);
    }

    attachPageSpecificListeners(pageName) {
        switch (pageName) {
            case "overview":
                this.initOverviewPage();
                break;
            case "bot-status":
                this.initBotStatusPage();
                break;
            case "add-sender":
                this.initAddSenderPage();
                break;
            case "list-sender":
                this.initListSenderPage();
                break;
            case "sender-status":
                this.initSenderStatusPage();
                break;
            case "xata-delay":
                this.initXataDelayPage();
                break;
            case "force-close":
                this.initForceClosePage();
                break;
            case "crash-target":
                this.initCrashTargetPage();
                break;
            case "user-management":
                this.initUserManagementPage();
                break;
            case "premium-control":
                this.initPremiumControlPage();
                break;
            case "system-config":
                this.initSystemConfigPage();
                break;
            case "cooldown-settings":
                this.initCooldownSettingsPage();
                break;
            case "wa-channel-info":
                this.initWAChannelInfoPage();
                break;
            case "token-validator":
                this.initTokenValidatorPage();
                break;
        }
    }

    // --- Page Content HTML --- //

    async getOverviewPage() {
        const overviewData = await APIUtils.handleAPICall(() => apiClient.getDashboardOverview());
        const data = overviewData.success ? overviewData.data : {};

        return `
            <div class="page-header">
                <h2>Dashboard Overview</h2>
                <p>Ringkasan status bot dan aktivitas pengguna.</p>
            </div>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon primary"><i class="fas fa-users"></i></div>
                    <div class="stat-value">${data.totalUsers || 0}</div>
                    <div class="stat-label">Total Users</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon success"><i class="fas fa-robot"></i></div>
                    <div class="stat-value">${data.activeSenders || 0}</div>
                    <div class="stat-label">Active Senders</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon warning"><i class="fas fa-crown"></i></div>
                    <div class="stat-value">${data.premiumUsers || 0}</div>
                    <div class="stat-label">Premium Users</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon danger"><i class="fas fa-bug"></i></div>
                    <div class="stat-value">${data.bugsSent || 0}</div>
                    <div class="stat-label">Bugs Sent</div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Recent Activity Logs</h3>
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Timestamp</th>
                                    <th>User</th>
                                    <th>Action</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody id="activityLogsTableBody">
                                ${data.recentActivities && data.recentActivities.length > 0 ?
                                    data.recentActivities.map(log => `
                                        <tr>
                                            <td>${formatDateTime(log.timestamp)}</td>
                                            <td>${escapeHtml(log.user)}</td>
                                            <td>${escapeHtml(log.action)}</td>
                                            <td>${escapeHtml(log.details)}</td>
                                        </tr>
                                    `).join("")
                                    : `<tr><td colspan="4" class="text-center">No recent activity.</td></tr>`
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    }

    async getBotStatusPage() {
        const botStatusData = await APIUtils.handleAPICall(() => apiClient.getBotStatus());
        const runtimeData = await APIUtils.handleAPICall(() => apiClient.getBotRuntime());
        const statsData = await APIUtils.handleAPICall(() => apiClient.getBotStats());

        const status = botStatusData.success ? botStatusData.data.status : CONFIG.STATUS.ERROR;
        const runtime = runtimeData.success ? runtimeData.data.runtime : "N/A";
        const stats = statsData.success ? statsData.data : {};

        return `
            <div class="page-header">
                <h2>Bot Status</h2>
                <p>Informasi terkini mengenai status dan performa bot.</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Bot Overview</h3>
                </div>
                <div class="card-body">
                    <p><strong>Status:</strong> <span class="status ${getStatusColor(status)}">${formatStatus(status)}</span></p>
                    <p><strong>Runtime:</strong> ${runtime}</p>
                    <p><strong>Total Pesan Terkirim:</strong> ${stats.messagesSent || 0}</p>
                    <p><strong>Total Sesi Aktif:</strong> ${stats.activeSessions || 0}</p>
                    <p><strong>Last Restart:</strong> ${formatDateTime(stats.lastRestart)}</p>
                </div>
            </div>
        `;
    }

    async getAddSenderPage() {
        if (!hasPermission("add_sender")) return this.getPermissionDeniedPage();
        return `
            <div class="page-header">
                <h2>Add New Sender</h2>
                <p>Tambahkan nomor WhatsApp baru untuk digunakan sebagai sender bot.</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Sender Details</h3>
                </div>
                <div class="card-body">
                    <form id="addSenderForm">
                        <div class="form-group">
                            <label for="phoneNumber">Phone Number (e.g., 6281234567890)</label>
                            <input type="text" id="phoneNumber" name="phoneNumber" placeholder="Enter phone number" required>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Add Sender</button>
                        </div>
                    </form>
                    <div id="pairingCodeDisplay" style="margin-top: 1.5rem; display: none;">
                        <h4>Pairing Code:</h4>
                        <pre id="pairingCodeValue" style="background: #f0f0f0; padding: 1rem; border-radius: 8px; overflow-x: auto;"></pre>
                        <button class="btn btn-secondary mt-2" onclick="copyToClipboard(document.getElementById(\'pairingCodeValue\').textContent)">Copy Code</button>
                    </div>
                </div>
            </div>
        `;
    }

    async getListSenderPage() {
        if (!hasPermission("list_sender")) return this.getPermissionDeniedPage();
        return `
            <div class="page-header">
                <h2>List Senders</h2>
                <p>Daftar semua nomor WhatsApp yang terdaftar sebagai sender bot.</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Registered Senders</h3>
                    <button class="btn btn-primary" onclick="window.pageManager.loadPage(\'add-sender\')">Add New</button>
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Phone Number</th>
                                    <th>Status</th>
                                    <th>Last Active</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="senderListTableBody">
                                <!-- Senders will be loaded here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    }

    async getSenderStatusPage() {
        return `
            <div class="page-header">
                <h2>Sender Status</h2>
                <p>Periksa status koneksi dan detail spesifik untuk setiap sender.</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Check Sender Status</h3>
                </div>
                <div class="card-body">
                    <form id="checkSenderStatusForm">
                        <div class="form-group">
                            <label for="statusSessionId">Session ID / Phone Number</label>
                            <input type="text" id="statusSessionId" name="statusSessionId" placeholder="Enter Session ID or Phone Number" required>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Check Status</button>
                        </div>
                    </form>
                    <div id="senderStatusResult" style="margin-top: 1.5rem; display: none;">
                        <h4>Sender Details:</h4>
                        <pre id="senderStatusValue" style="background: #f0f0f0; padding: 1rem; border-radius: 8px; overflow-x: auto;"></pre>
                    </div>
                </div>
            </div>
        `;
    }

    async getXataDelayPage() {
        if (!hasPermission("bug_menu")) return this.getPermissionDeniedPage();
        return `
            <div class="page-header">
                <h2>Xata Delay Bug</h2>
                <p>Kirim pesan bug delay ke target WhatsApp.</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Send Xata Delay</h3>
                </div>
                <div class="card-body">
                    <form id="xataDelayForm">
                        <div class="form-group">
                            <label for="xataDelayTarget">Target JID (e.g., 6281234567890@s.whatsapp.net)</label>
                            <input type="text" id="xataDelayTarget" name="target" placeholder="Enter target JID" required>
                        </div>
                        <div class="form-group">
                            <label for="xataDelaySender">Sender Session ID</label>
                            <input type="text" id="xataDelaySender" name="sessionId" placeholder="Enter sender session ID" required>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-danger">Send Bug</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
    }

    async getForceClosePage() {
        if (!hasPermission("force_close")) return this.getPermissionDeniedPage();
        return `
            <div class="page-header">
                <h2>Force Close Bug</h2>
                <p>Kirim pesan bug untuk memaksa penutupan aplikasi WhatsApp target.</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Send Force Close</h3>
                </div>
                <div class="card-body">
                    <form id="forceCloseForm">
                        <div class="form-group">
                            <label for="forceCloseTarget">Target JID (e.g., 6281234567890@s.whatsapp.net)</label>
                            <input type="text" id="forceCloseTarget" name="target" placeholder="Enter target JID" required>
                        </div>
                        <div class="form-group">
                            <label for="forceCloseSender">Sender Session ID</label>
                            <input type="text" id="forceCloseSender" name="sessionId" placeholder="Enter sender session ID" required>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-danger">Send Bug</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
    }

    async getCrashTargetPage() {
        if (!hasPermission("crash_target")) return this.getPermissionDeniedPage();
        return `
            <div class="page-header">
                <h2>Crash Target Bug</h2>
                <p>Kirim pesan bug untuk membuat aplikasi WhatsApp target crash.</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Send Crash Target</h3>
                </div>
                <div class="card-body">
                    <form id="crashTargetForm">
                        <div class="form-group">
                            <label for="crashTargetJid">Target JID (e.g., 6281234567890@s.whatsapp.net)</label>
                            <input type="text" id="crashTargetJid" name="target" placeholder="Enter target JID" required>
                        </div>
                        <div class="form-group">
                            <label for="crashTargetSender">Sender Session ID</label>
                            <input type="text" id="crashTargetSender" name="sessionId" placeholder="Enter sender session ID" required>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-danger">Send Bug</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
    }

    async getUserManagementPage() {
        if (!hasPermission("user_management")) return this.getPermissionDeniedPage();
        return `
            <div class="page-header">
                <h2>User Management</h2>
                <p>Kelola pengguna dashboard, termasuk Owner, Admin, dan Premium.</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">All Users</h3>
                    <button class="btn btn-primary" id="createUserBtn">Create New User</button>
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>User ID</th>
                                    <th>Username</th>
                                    <th>Role</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="userListTableBody">
                                <!-- Users will be loaded here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Create/Edit User Modal -->
            <div id="userModal" class="modal" style="display: none;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 id="userModalTitle">Create User</h3>
                        <span class="close-button" onclick="document.getElementById(\'userModal\').style.display=\'none\'">&times;</span>
                    </div>
                    <form id="userForm">
                        <input type="hidden" id="userId" name="userId">
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" id="username" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" placeholder="Leave blank to keep current password">
                        </div>
                        <div class="form-group">
                            <label for="role">Role</label>
                            <select id="role" name="role" required>
                                <option value="owner">Owner</option>
                                <option value="admin">Admin</option>
                                <option value="premium">Premium</option>
                            </select>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Save User</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
    }

    async getPremiumControlPage() {
        if (!hasPermission("premium_control")) return this.getPermissionDeniedPage();
        return `
            <div class="page-header">
                <h2>Premium Control</h2>
                <p>Kelola status premium pengguna.</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Premium Users</h3>
                    <button class="btn btn-primary" id="addPremiumUserBtn">Add Premium User</button>
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>User ID</th>
                                    <th>Username</th>
                                    <th>Expires At</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="premiumUserListTableBody">
                                <!-- Premium users will be loaded here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Add/Extend Premium Modal -->
            <div id="premiumModal" class="modal" style="display: none;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 id="premiumModalTitle">Add Premium User</h3>
                        <span class="close-button" onclick="document.getElementById(\'premiumModal\').style.display=\'none\'">&times;</span>
                    </div>
                    <form id="premiumForm">
                        <div class="form-group">
                            <label for="premiumUserId">User ID</label>
                            <input type="text" id="premiumUserId" name="userId" required>
                        </div>
                        <div class="form-group">
                            <label for="premiumExpiresAt">Expires At (YYYY-MM-DD)</label>
                            <input type="date" id="premiumExpiresAt" name="expiresAt" required>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
    }

    async getSystemConfigPage() {
        if (!hasPermission("system_config")) return this.getPermissionDeniedPage();
        return `
            <div class="page-header">
                <h2>System Configuration</h2>
                <p>Kelola pengaturan sistem bot.</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Bot Settings</h3>
                </div>
                <div class="card-body">
                    <form id="systemConfigForm">
                        <div class="form-group">
                            <label for="botName">Bot Name</label>
                            <input type="text" id="botName" name="botName" required>
                        </div>
                        <div class="form-group">
                            <label for="maxSessions">Max WhatsApp Sessions</label>
                            <input type="number" id="maxSessions" name="maxSessions" required>
                        </div>
                        <div class="form-group">
                            <label for="autoRestart">Auto Restart Bot</label>
                            <select id="autoRestart" name="autoRestart">
                                <option value="true">True</option>
                                <option value="false">False</option>
                            </select>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Save Config</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
    }

    async getCooldownSettingsPage() {
        if (!hasPermission("cooldown_settings")) return this.getPermissionDeniedPage();
        return `
            <div class="page-header">
                <h2>Cooldown Settings</h2>
                <p>Atur waktu cooldown untuk perintah bot.</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Set Cooldown</h3>
                </div>
                <div class="card-body">
                    <form id="setCooldownForm">
                        <div class="form-group">
                            <label for="cooldownTime">Cooldown Time (e.g., 5m, 30s, 1h)</label>
                            <input type="text" id="cooldownTime" name="cooldownTime" placeholder="Enter cooldown time" required>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Set Cooldown</button>
                        </div>
                    </form>
                    <div id="currentCooldownDisplay" style="margin-top: 1.5rem;">
                        <h4>Current Cooldown: <span id="currentCooldownValue">Loading...</span></h4>
                    </div>
                </div>
            </div>
        `;
    }

    async getWAChannelInfoPage() {
        return `
            <div class="page-header">
                <h2>WhatsApp Channel Info</h2>
                <p>Dapatkan informasi detail tentang channel WhatsApp.</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Get Channel Info</h3>
                </div>
                <div class="card-body">
                    <form id="waChannelInfoForm">
                        <div class="form-group">
                            <label for="channelLink">WhatsApp Channel Link</label>
                            <input type="url" id="channelLink" name="channelLink" placeholder="e.g., https://whatsapp.com/channel/0000000000" required>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Get Info</button>
                        </div>
                    </form>
                    <div id="channelInfoResult" style="margin-top: 1.5rem; display: none;">
                        <h4>Channel Details:</h4>
                        <pre id="channelInfoValue" style="background: #f0f0f0; padding: 1rem; border-radius: 8px; overflow-x: auto;"></pre>
                    </div>
                </div>
            </div>
        `;
    }

    async getTokenValidatorPage() {
        if (!hasPermission("token_validator")) return this.getPermissionDeniedPage();
        return `
            <div class="page-header">
                <h2>Bot Token Validator</h2>
                <p>Validasi token akses bot Telegram.</p>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Validate Token</h3>
                </div>
                <div class="card-body">
                    <form id="tokenValidatorForm">
                        <div class="form-group">
                            <label for="botToken">Bot Token</label>
                            <input type="text" id="botToken" name="botToken" placeholder="Enter bot token" required>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Validate</button>
                        </div>
                    </form>
                    <div id="tokenValidationResult" style="margin-top: 1.5rem; display: none;">
                        <h4>Validation Result:</h4>
                        <pre id="tokenValidationValue" style="background: #f0f0f0; padding: 1rem; border-radius: 8px; overflow-x: auto;"></pre>
                    </div>
                </div>
            </div>
        `;
    }

    getPermissionDeniedPage() {
        return `
            <div class="page-header">
                <h2>Access Denied</h2>
                <p>Anda tidak memiliki izin untuk mengakses halaman ini.</p>
            </div>
            <div class="card">
                <div class="card-body text-center">
                    <i class="fas fa-lock fa-5x" style="color: #ef4444; margin-bottom: 1rem;"></i>
                    <p>Silakan hubungi administrator jika Anda merasa ini adalah kesalahan.</p>
                </div>
            </div>
        `;
    }

    // --- Page Specific Initializers --- //

    async initOverviewPage() {
        const overviewData = await APIUtils.handleAPICall(() => apiClient.getDashboardOverview());
        if (overviewData.success) {
            // Update UI with data
            document.querySelector(".stat-card:nth-child(1) .stat-value").textContent = overviewData.data.totalUsers || 0;
            document.querySelector(".stat-card:nth-child(2) .stat-value").textContent = overviewData.data.activeSenders || 0;
            document.querySelector(".stat-card:nth-child(3) .stat-value").textContent = overviewData.data.premiumUsers || 0;
            document.querySelector(".stat-card:nth-child(4) .stat-value").textContent = overviewData.data.bugsSent || 0;

            const activityLogsTableBody = document.getElementById("activityLogsTableBody");
            if (activityLogsTableBody) {
                activityLogsTableBody.innerHTML = overviewData.data.recentActivities && overviewData.data.recentActivities.length > 0 ?
                    overviewData.data.recentActivities.map(log => `
                        <tr>
                            <td>${formatDateTime(log.timestamp)}</td>
                            <td>${escapeHtml(log.user)}</td>
                            <td>${escapeHtml(log.action)}</td>
                            <td>${escapeHtml(log.details)}</td>
                        </tr>
                    `).join("")
                    : `<tr><td colspan="4" class="text-center">No recent activity.</td></tr>`;
            }
        }
    }

    async initBotStatusPage() {
        const botStatusData = await APIUtils.handleAPICall(() => apiClient.getBotStatus());
        const runtimeData = await APIUtils.handleAPICall(() => apiClient.getBotRuntime());
        const statsData = await APIUtils.handleAPICall(() => apiClient.getBotStats());

        if (botStatusData.success) {
            const statusElement = document.querySelector("#botStatusPage .status");
            if (statusElement) {
                statusElement.textContent = formatStatus(botStatusData.data.status);
                statusElement.className = `status ${getStatusColor(botStatusData.data.status)}`;
            }
        }
        if (runtimeData.success) {
            document.querySelector("#botStatusPage p:nth-child(2)").innerHTML = `<strong>Runtime:</strong> ${runtimeData.data.runtime}`;
        }
        if (statsData.success) {
            document.querySelector("#botStatusPage p:nth-child(3)").innerHTML = `<strong>Total Pesan Terkirim:</strong> ${statsData.data.messagesSent || 0}`;
            document.querySelector("#botStatusPage p:nth-child(4)").innerHTML = `<strong>Total Sesi Aktif:</strong> ${statsData.data.activeSessions || 0}`;
            document.querySelector("#botStatusPage p:nth-child(5)").innerHTML = `<strong>Last Restart:</strong> ${formatDateTime(statsData.data.lastRestart)}`;
        }
    }

    initAddSenderPage() {
        const form = document.getElementById("addSenderForm");
        const pairingCodeDisplay = document.getElementById("pairingCodeDisplay");
        const pairingCodeValue = document.getElementById("pairingCodeValue");

        if (form) {
            form.addEventListener("submit", async (e) => {
                e.preventDefault();
                clearFormErrors();

                const phoneNumber = sanitizeInput(document.getElementById("phoneNumber").value);
                const validation = validateForm({ phoneNumber }, {
                    phoneNumber: { required: true, custom: isValidPhoneNumber, message: "Invalid phone number format." }
                });

                if (!validation.isValid) {
                    showFormErrors(validation.errors);
                    return;
                }

                const result = await APIUtils.handleFormSubmit(form, () => apiClient.addSender(phoneNumber), CONFIG.SUCCESS.SENDER_ADDED);
                if (result.success && result.data.pairingCode) {
                    pairingCodeValue.textContent = result.data.pairingCode;
                    pairingCodeDisplay.style.display = "block";
                } else {
                    pairingCodeDisplay.style.display = "none";
                }
            });
        }
    }

    async initListSenderPage() {
        const tableBody = document.getElementById("senderListTableBody");
        if (!tableBody) return;

        showLoading(tableBody, "Loading senders...");
        const result = await APIUtils.handleAPICall(() => apiClient.getSenders());

        if (result.success && result.data.senders) {
            tableBody.innerHTML = result.data.senders.length > 0 ?
                result.data.senders.map(sender => `
                    <tr>
                        <td>${escapeHtml(sender.phoneNumber)}</td>
                        <td><span class="status ${getStatusColor(sender.status)}">${formatStatus(sender.status)}</span></td>
                        <td>${formatDateTime(sender.lastActive)}</td>
                        <td>
                            <button class="btn btn-sm btn-primary" onclick="window.pageManager.connectSender(\'${escapeHtml(sender.sessionId)}\')">Connect</button>
                            <button class="btn btn-sm btn-warning" onclick="window.pageManager.disconnectSender(\'${escapeHtml(sender.sessionId)}\')">Disconnect</button>
                            ${hasPermission("delete_sender") ? `<button class="btn btn-sm btn-danger" onclick="window.pageManager.deleteSender(\'${escapeHtml(sender.sessionId)}\')">Delete</button>` : ``}
                        </td>
                    </tr>
                `).join("")
                : `<tr><td colspan="4" class="text-center">No senders registered.</td></tr>`;
        } else {
            tableBody.innerHTML = `<tr><td colspan="4" class="text-center">Failed to load senders.</td></tr>`;
        }
    }

    async connectSender(sessionId) {
        await APIUtils.handleAPICall(() => apiClient.connectSender(sessionId), `Connecting sender ${sessionId}...`);
        this.loadPage("list-sender"); // Refresh list
    }

    async disconnectSender(sessionId) {
        await APIUtils.handleAPICall(() => apiClient.disconnectSender(sessionId), `Disconnecting sender ${sessionId}...`);
        this.loadPage("list-sender"); // Refresh list
    }

    async deleteSender(sessionId) {
        if (!confirm(`Are you sure you want to delete sender ${sessionId}?`)) return;
        await APIUtils.handleAPICall(() => apiClient.deleteSender(sessionId), CONFIG.SUCCESS.SENDER_DELETED);
        this.loadPage("list-sender"); // Refresh list
    }

    initSenderStatusPage() {
        const form = document.getElementById("checkSenderStatusForm");
        const resultDisplay = document.getElementById("senderStatusResult");
        const resultValue = document.getElementById("senderStatusValue");

        if (form) {
            form.addEventListener("submit", async (e) => {
                e.preventDefault();
                clearFormErrors();

                const sessionId = sanitizeInput(document.getElementById("statusSessionId").value);
                if (!sessionId) {
                    showFormErrors({ statusSessionId: "Session ID or Phone Number is required." });
                    return;
                }

                showLoading(resultDisplay, "Checking status...");
                resultDisplay.style.display = "block";

                const result = await APIUtils.handleAPICall(() => apiClient.getSenderStatus(sessionId));
                if (result.success) {
                    resultValue.textContent = JSON.stringify(result.data, null, 2);
                } else {
                    resultValue.textContent = `Error: ${result.error || "Failed to get status."}`;
                }
            });
        }
    }

    initXataDelayPage() {
        const form = document.getElementById("xataDelayForm");
        if (form) {
            form.addEventListener("submit", async (e) => {
                e.preventDefault();
                clearFormErrors();

                const target = sanitizeInput(document.getElementById("xataDelayTarget").value);
                const sessionId = sanitizeInput(document.getElementById("xataDelaySender").value);

                const validation = validateForm({ target, sessionId }, {
                    target: { required: true, message: "Target JID is required." },
                    sessionId: { required: true, message: "Sender Session ID is required." }
                });

                if (!validation.isValid) {
                    showFormErrors(validation.errors);
                    return;
                }

                await APIUtils.handleFormSubmit(form, () => apiClient.sendXataDelay(target, sessionId), CONFIG.SUCCESS.BUG_SENT);
            });
        }
    }

    initForceClosePage() {
        const form = document.getElementById("forceCloseForm");
        if (form) {
            form.addEventListener("submit", async (e) => {
                e.preventDefault();
                clearFormErrors();

                const target = sanitizeInput(document.getElementById("forceCloseTarget").value);
                const sessionId = sanitizeInput(document.getElementById("forceCloseSender").value);

                const validation = validateForm({ target, sessionId }, {
                    target: { required: true, message: "Target JID is required." },
                    sessionId: { required: true, message: "Sender Session ID is required." }
                });

                if (!validation.isValid) {
                    showFormErrors(validation.errors);
                    return;
                }

                await APIUtils.handleFormSubmit(form, () => apiClient.sendForceClose(target, sessionId), CONFIG.SUCCESS.BUG_SENT);
            });
        }
    }

    initCrashTargetPage() {
        const form = document.getElementById("crashTargetForm");
        if (form) {
            form.addEventListener("submit", async (e) => {
                e.preventDefault();
                clearFormErrors();

                const target = sanitizeInput(document.getElementById("crashTargetJid").value);
                const sessionId = sanitizeInput(document.getElementById("crashTargetSender").value);

                const validation = validateForm({ target, sessionId }, {
                    target: { required: true, message: "Target JID is required." },
                    sessionId: { required: true, message: "Sender Session ID is required." }
                });

                if (!validation.isValid) {
                    showFormErrors(validation.errors);
                    return;
                }

                await APIUtils.handleFormSubmit(form, () => apiClient.sendCrashTarget(target, sessionId), CONFIG.SUCCESS.BUG_SENT);
            });
        }
    }

    async initUserManagementPage() {
        const tableBody = document.getElementById("userListTableBody");
        const createUserBtn = document.getElementById("createUserBtn");
        const userModal = document.getElementById("userModal");
        const userModalTitle = document.getElementById("userModalTitle");
        const userForm = document.getElementById("userForm");

        const loadUsers = async () => {
            showLoading(tableBody, "Loading users...");
            const result = await APIUtils.handleAPICall(() => apiClient.getUsers());
            if (result.success && result.data.users) {
                tableBody.innerHTML = result.data.users.length > 0 ?
                    result.data.users.map(user => `
                        <tr>
                            <td>${escapeHtml(user.userId)}</td>
                            <td>${escapeHtml(user.username)}</td>
                            <td>${escapeHtml(user.role)}</td>
                            <td>
                                <button class="btn btn-sm btn-secondary" onclick="window.pageManager.editUser(\'${escapeHtml(user.userId)}\')">Edit</button>
                                <button class="btn btn-sm btn-danger" onclick="window.pageManager.deleteUser(\'${escapeHtml(user.userId)}\')">Delete</button>
                            </td>
                        </tr>
                    `).join("")
                    : `<tr><td colspan="4" class="text-center">No users registered.</td></tr>`;
            } else {
                tableBody.innerHTML = `<tr><td colspan="4" class="text-center">Failed to load users.</td></tr>`;
            }
        };

        if (createUserBtn) {
            createUserBtn.addEventListener("click", () => {
                userModalTitle.textContent = "Create User";
                userForm.reset();
                document.getElementById("userId").value = "";
                document.getElementById("password").setAttribute("required", "required");
                userModal.style.display = "flex";
            });
        }

        if (userForm) {
            userForm.addEventListener("submit", async (e) => {
                e.preventDefault();
                clearFormErrors();

                const userId = document.getElementById("userId").value;
                const username = sanitizeInput(document.getElementById("username").value);
                const password = document.getElementById("password").value;
                const role = document.getElementById("role").value;

                const userData = { username, role };
                if (password) userData.password = password;

                const validationRules = {
                    username: { required: true },
                    role: { required: true }
                };
                if (!userId) {
                    validationRules.password = { required: true, minLength: 6, message: "Password is required and must be at least 6 characters." };
                }

                const validation = validateForm(userData, validationRules);
                if (!validation.isValid) {
                    showFormErrors(validation.errors);
                    return;
                }

                let result;
                if (userId) {
                    result = await APIUtils.handleFormSubmit(userForm, () => apiClient.updateUser(userId, userData), CONFIG.SUCCESS.USER_UPDATED);
                } else {
                    result = await APIUtils.handleFormSubmit(userForm, () => apiClient.createUser(userData), CONFIG.SUCCESS.USER_CREATED);
                }

                if (result.success) {
                    userModal.style.display = "none";
                    loadUsers();
                }
            });
        }

        loadUsers();
    }

    async editUser(userId) {
        const userModal = document.getElementById("userModal");
        const userModalTitle = document.getElementById("userModalTitle");
        const userForm = document.getElementById("userForm");

        userModalTitle.textContent = "Edit User";
        userForm.reset();
        document.getElementById("password").removeAttribute("required");

        const result = await APIUtils.handleAPICall(() => apiClient.getUsers()); // Get all users and find the one to edit
        if (result.success && result.data.users) {
            const userToEdit = result.data.users.find(u => u.userId === userId);
            if (userToEdit) {
                document.getElementById("userId").value = userToEdit.userId;
                document.getElementById("username").value = userToEdit.username;
                document.getElementById("role").value = userToEdit.role;
                userModal.style.display = "flex";
            } else {
                showToast("error", "Error", "User not found.");
            }
        }
    }

    async deleteUser(userId) {
        if (!confirm(`Are you sure you want to delete user ${userId}?`)) return;
        await APIUtils.handleAPICall(() => apiClient.deleteUser(userId), `User ${userId} deleted successfully.`);
        this.loadPage("user-management"); // Refresh list
    }

    async initPremiumControlPage() {
        const tableBody = document.getElementById("premiumUserListTableBody");
        const addPremiumUserBtn = document.getElementById("addPremiumUserBtn");
        const premiumModal = document.getElementById("premiumModal");
        const premiumModalTitle = document.getElementById("premiumModalTitle");
        const premiumForm = document.getElementById("premiumForm");

        const loadPremiumUsers = async () => {
            showLoading(tableBody, "Loading premium users...");
            const result = await APIUtils.handleAPICall(() => apiClient.getPremiumUsers());
            if (result.success && result.data.premiumUsers) {
                tableBody.innerHTML = result.data.premiumUsers.length > 0 ?
                    result.data.premiumUsers.map(user => `
                        <tr>
                            <td>${escapeHtml(user.userId)}</td>
                            <td>${escapeHtml(user.username)}</td>
                            <td>${formatDateTime(user.expiresAt)}</td>
                            <td><span class="status ${getStatusColor(user.status)}">${formatStatus(user.status)}</span></td>
                            <td>
                                <button class="btn btn-sm btn-primary" onclick="window.pageManager.extendPremium(\'${escapeHtml(user.userId)}\')">Extend</button>
                                <button class="btn btn-sm btn-danger" onclick="window.pageManager.removePremiumUser(\'${escapeHtml(user.userId)}\')">Remove</button>
                            </td>
                        </tr>
                    `).join("")
                    : `<tr><td colspan="5" class="text-center">No premium users.</td></tr>`;
            } else {
                tableBody.innerHTML = `<tr><td colspan="5" class="text-center">Failed to load premium users.</td></tr>`;
            }
        };

        if (addPremiumUserBtn) {
            addPremiumUserBtn.addEventListener("click", () => {
                premiumModalTitle.textContent = "Add Premium User";
                premiumForm.reset();
                document.getElementById("premiumUserId").removeAttribute("readonly");
                premiumModal.style.display = "flex";
            });
        }

        if (premiumForm) {
            premiumForm.addEventListener("submit", async (e) => {
                e.preventDefault();
                clearFormErrors();

                const userId = sanitizeInput(document.getElementById("premiumUserId").value);
                const expiresAt = document.getElementById("premiumExpiresAt").value;

                const validation = validateForm({ userId, expiresAt }, {
                    userId: { required: true },
                    expiresAt: { required: true }
                });

                if (!validation.isValid) {
                    showFormErrors(validation.errors);
                    return;
                }

                let result;
                if (premiumModalTitle.textContent === "Add Premium User") {
                    result = await APIUtils.handleFormSubmit(premiumForm, () => apiClient.addPremiumUser(userId, expiresAt), CONFIG.SUCCESS.PREMIUM_UPDATED);
                } else {
                    // This is for extend premium, which is handled by a separate function
                    // For simplicity, we'll just reload the page after form submission
                    result = { success: true }; // Assume success for now
                }

                if (result.success) {
                    premiumModal.style.display = "none";
                    loadPremiumUsers();
                }
            });
        }

        loadPremiumUsers();
    }

    async extendPremium(userId) {
        const days = prompt(`Enter number of days to extend premium for ${userId}:`);
        if (days && !isNaN(days) && parseInt(days) > 0) {
            await APIUtils.handleAPICall(() => apiClient.extendPremium(userId, parseInt(days)), `Premium for ${userId} extended by ${days} days.`);
            this.loadPage("premium-control"); // Refresh list
        } else if (days !== null) {
            showToast("error", "Invalid Input", "Please enter a valid number of days.");
        }
    }

    async removePremiumUser(userId) {
        if (!confirm(`Are you sure you want to remove premium status for ${userId}?`)) return;
        await APIUtils.handleAPICall(() => apiClient.removePremiumUser(userId), `Premium status for ${userId} removed.`);
        this.loadPage("premium-control"); // Refresh list
    }

    async initSystemConfigPage() {
        const form = document.getElementById("systemConfigForm");
        const loadConfig = async () => {
            showLoading(form, "Loading configuration...");
            const result = await APIUtils.handleAPICall(() => apiClient.getSystemConfig());
            if (result.success && result.data.config) {
                document.getElementById("botName").value = result.data.config.botName || "";
                document.getElementById("maxSessions").value = result.data.config.maxSessions || 0;
                document.getElementById("autoRestart").value = String(result.data.config.autoRestart || false);
            }
            hideLoading(form);
        };

        if (form) {
            form.addEventListener("submit", async (e) => {
                e.preventDefault();
                clearFormErrors();

                const botName = sanitizeInput(document.getElementById("botName").value);
                const maxSessions = parseInt(document.getElementById("maxSessions").value);
                const autoRestart = document.getElementById("autoRestart").value === "true";

                const configData = { botName, maxSessions, autoRestart };

                const validation = validateForm(configData, {
                    botName: { required: true },
                    maxSessions: { required: true, custom: (val) => val > 0, message: "Max Sessions must be a positive number." }
                });

                if (!validation.isValid) {
                    showFormErrors(validation.errors);
                    return;
                }

                await APIUtils.handleFormSubmit(form, () => apiClient.updateSystemConfig(configData), CONFIG.SUCCESS.CONFIG_UPDATED);
                loadConfig();
            });
        }
        loadConfig();
    }

    async initCooldownSettingsPage() {
        const form = document.getElementById("setCooldownForm");
        const currentCooldownValue = document.getElementById("currentCooldownValue");

        const loadCooldown = async () => {
            const result = await APIUtils.handleAPICall(() => apiClient.getCooldownSettings());
            if (result.success && result.data.cooldown) {
                currentCooldownValue.textContent = formatCooldownTime(result.data.cooldown.time);
            } else {
                currentCooldownValue.textContent = "Failed to load";
            }
        };

        if (form) {
            form.addEventListener("submit", async (e) => {
                e.preventDefault();
                clearFormErrors();

                const cooldownTime = sanitizeInput(document.getElementById("cooldownTime").value);
                const parsedTime = parseCooldownTime(cooldownTime);

                if (!parsedTime) {
                    showFormErrors({ cooldownTime: "Invalid format. Use e.g., 5m, 30s, 1h." });
                    return;
                }

                await APIUtils.handleFormSubmit(form, () => apiClient.setCooldown(cooldownTime), `Cooldown set to ${cooldownTime}.`);
                loadCooldown();
            });
        }
        loadCooldown();
    }

    initWAChannelInfoPage() {
        const form = document.getElementById("waChannelInfoForm");
        const resultDisplay = document.getElementById("channelInfoResult");
        const resultValue = document.getElementById("channelInfoValue");

        if (form) {
            form.addEventListener("submit", async (e) => {
                e.preventDefault();
                clearFormErrors();

                const channelLink = sanitizeInput(document.getElementById("channelLink").value);
                if (!isValidWhatsAppChannelLink(channelLink)) {
                    showFormErrors({ channelLink: "Invalid WhatsApp channel link." });
                    return;
                }

                showLoading(resultDisplay, "Getting channel info...");
                resultDisplay.style.display = "block";

                const result = await APIUtils.handleAPICall(() => apiClient.getWhatsAppChannelInfo(channelLink));
                if (result.success) {
                    resultValue.textContent = JSON.stringify(result.data, null, 2);
                } else {
                    resultValue.textContent = `Error: ${result.error || "Failed to get channel info."}`;
                }
            });
        }
    }

    initTokenValidatorPage() {
        const form = document.getElementById("tokenValidatorForm");
        const resultDisplay = document.getElementById("tokenValidationResult");
        const resultValue = document.getElementById("tokenValidationValue");

        if (form) {
            form.addEventListener("submit", async (e) => {
                e.preventDefault();
                clearFormErrors();

                const botToken = sanitizeInput(document.getElementById("botToken").value);
                if (!botToken) {
                    showFormErrors({ botToken: "Bot Token is required." });
                    return;
                }

                showLoading(resultDisplay, "Validating token...");
                resultDisplay.style.display = "block";

                const result = await APIUtils.handleAPICall(() => apiClient.validateBotToken(botToken));
                if (result.success) {
                    resultValue.textContent = JSON.stringify(result.data, null, 2);
                } else {
                    resultValue.textContent = `Error: ${result.error || "Failed to validate token."}`;
                }
            });
        }
    }
}

// Initialize page manager
const pageManager = new PageManager();

// Export for use in other modules
window.pageManager = pageManager;

