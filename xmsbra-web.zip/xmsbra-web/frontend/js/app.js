// XMSBRA Main Application Module

class XMSBRAApp {
    constructor() {
        this.isInitialized = false;
        this.autoRefreshInterval = null;
    }

    async init() {
        if (this.isInitialized) return;

        console.log('Initializing XMSBRA Dashboard...');
        
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.init());
            return;
        }

        try {
            // Initialize navigation
            this.initNavigation();
            
            // Initialize auto-refresh
            this.initAutoRefresh();
            
            // Initialize keyboard shortcuts
            this.initKeyboardShortcuts();
            
            // Initialize tooltips and UI enhancements
            this.initUIEnhancements();
            
            // Mark as initialized
            this.isInitialized = true;
            
            console.log('XMSBRA Dashboard initialized successfully');
            
        } catch (error) {
            console.error('Failed to initialize XMSBRA Dashboard:', error);
            window.showToast('error', 'Initialization Error', 'Failed to initialize dashboard');
        }
    }

    initNavigation() {
        // Handle navigation clicks
        document.addEventListener('click', (e) => {
            const navLink = e.target.closest('.nav-link');
            if (navLink && navLink.hasAttribute('data-page')) {
                e.preventDefault();
                const page = navLink.getAttribute('data-page');
                
                // Check permissions before loading page
                const permission = window.authManager.getPermissionForPage(page);
                if (permission && !window.authManager.hasPermission(permission)) {
                    window.showToast('error', 'Access Denied', 'You do not have permission to access this page');
                    return;
                }
                
                window.pageManager.loadPage(page);
            }
        });

        // Handle mobile menu toggle (if needed)
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const sidebar = document.querySelector('.sidebar');
        
        if (mobileMenuToggle && sidebar) {
            mobileMenuToggle.addEventListener('click', () => {
                sidebar.classList.toggle('mobile-open');
            });
        }
    }

    initAutoRefresh() {
        // Auto-refresh certain data every 30 seconds
        this.autoRefreshInterval = setInterval(() => {
            if (window.authManager && window.authManager.isAuthenticated) {
                this.refreshCurrentPageData();
            }
        }, CONFIG.AUTO_REFRESH_INTERVAL);
    }

    async refreshCurrentPageData() {
        const currentPage = window.pageManager.currentPage;
        
        // Only refresh data for pages that benefit from real-time updates
        const refreshablePages = ['overview', 'bot-status', 'list-sender', 'sender-status'];
        
        if (refreshablePages.includes(currentPage)) {
            try {
                // Silently refresh data without showing loading states
                switch (currentPage) {
                    case 'overview':
                        await this.refreshOverviewData();
                        break;
                    case 'bot-status':
                        await this.refreshBotStatusData();
                        break;
                    case 'list-sender':
                        await this.refreshSenderListData();
                        break;
                }
            } catch (error) {
                console.warn('Auto-refresh failed:', error);
                // Don't show error toast for auto-refresh failures
            }
        }
    }

    async refreshOverviewData() {
        const result = await window.apiClient.getDashboardOverview();
        if (result) {
            // Update stats cards
            const statCards = document.querySelectorAll('.stat-card .stat-value');
            if (statCards.length >= 4) {
                statCards[0].textContent = result.totalUsers || 0;
                statCards[1].textContent = result.activeSenders || 0;
                statCards[2].textContent = result.premiumUsers || 0;
                statCards[3].textContent = result.bugsSent || 0;
            }
        }
    }

    async refreshBotStatusData() {
        const statusResult = await window.apiClient.getBotStatus();
        if (statusResult) {
            const statusElement = document.querySelector('.status');
            if (statusElement) {
                statusElement.textContent = window.formatStatus(statusResult.status);
                statusElement.className = `status ${window.getStatusColor(statusResult.status)}`;
            }
        }
    }

    async refreshSenderListData() {
        const result = await window.apiClient.getSenders();
        if (result && result.senders) {
            const tableBody = document.getElementById('senderListTableBody');
            if (tableBody) {
                tableBody.innerHTML = result.senders.length > 0 ?
                    result.senders.map(sender => `
                        <tr>
                            <td>${window.escapeHtml(sender.phoneNumber)}</td>
                            <td><span class="status ${window.getStatusColor(sender.status)}">${window.formatStatus(sender.status)}</span></td>
                            <td>${window.formatDateTime(sender.lastActive)}</td>
                            <td>
                                <button class="btn btn-sm btn-primary" onclick="window.pageManager.connectSender('${window.escapeHtml(sender.sessionId)}')">Connect</button>
                                <button class="btn btn-sm btn-warning" onclick="window.pageManager.disconnectSender('${window.escapeHtml(sender.sessionId)}')">Disconnect</button>
                                ${window.hasPermission('delete_sender') ? `<button class="btn btn-sm btn-danger" onclick="window.pageManager.deleteSender('${window.escapeHtml(sender.sessionId)}')">Delete</button>` : ''}
                            </td>
                        </tr>
                    `).join('')
                    : `<tr><td colspan="4" class="text-center">No senders registered.</td></tr>`;
            }
        }
    }

    initKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Only handle shortcuts when not typing in input fields
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                return;
            }

            // Ctrl/Cmd + shortcuts
            if (e.ctrlKey || e.metaKey) {
                switch (e.key) {
                    case 'h':
                        e.preventDefault();
                        window.pageManager.loadPage('overview');
                        break;
                    case 's':
                        e.preventDefault();
                        window.pageManager.loadPage('list-sender');
                        break;
                    case 'b':
                        e.preventDefault();
                        window.pageManager.loadPage('bot-status');
                        break;
                    case 'l':
                        e.preventDefault();
                        window.authManager.logout();
                        break;
                }
            }

            // Number shortcuts for quick navigation
            if (e.key >= '1' && e.key <= '9') {
                const pageMap = {
                    '1': 'overview',
                    '2': 'bot-status',
                    '3': 'add-sender',
                    '4': 'list-sender',
                    '5': 'xata-delay',
                    '6': 'force-close',
                    '7': 'crash-target',
                    '8': 'user-management',
                    '9': 'premium-control'
                };
                
                const page = pageMap[e.key];
                if (page) {
                    e.preventDefault();
                    const permission = window.authManager.getPermissionForPage(page);
                    if (!permission || window.authManager.hasPermission(permission)) {
                        window.pageManager.loadPage(page);
                    }
                }
            }

            // Escape key to close modals
            if (e.key === 'Escape') {
                const modals = document.querySelectorAll('.modal');
                modals.forEach(modal => {
                    if (modal.style.display === 'flex') {
                        modal.style.display = 'none';
                    }
                });
            }
        });
    }

    initUIEnhancements() {
        // Add loading states to buttons
        this.enhanceButtons();
        
        // Add form validation enhancements
        this.enhanceFormValidation();
        
        // Add table enhancements
        this.enhanceTableInteractions();
        
        // Add tooltip functionality
        this.initTooltips();
        
        // Add copy-to-clipboard functionality
        this.initCopyButtons();
    }

    enhanceButtons() {
        document.addEventListener('click', (e) => {
            const button = e.target.closest('button[type="submit"]');
            if (button && !button.disabled) {
                // Add ripple effect
                this.addRippleEffect(button, e);
            }
        });
    }

    addRippleEffect(element, event) {
        const ripple = document.createElement('span');
        const rect = element.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = event.clientX - rect.left - size / 2;
        const y = event.clientY - rect.top - size / 2;
        
        ripple.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            left: ${x}px;
            top: ${y}px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            transform: scale(0);
            animation: ripple 0.6s linear;
            pointer-events: none;
        `;
        
        // Add ripple animation CSS if not already added
        if (!document.getElementById('ripple-styles')) {
            const style = document.createElement('style');
            style.id = 'ripple-styles';
            style.textContent = `
                @keyframes ripple {
                    to {
                        transform: scale(4);
                        opacity: 0;
                    }
                }
                button {
                    position: relative;
                    overflow: hidden;
                }
            `;
            document.head.appendChild(style);
        }
        
        element.appendChild(ripple);
        setTimeout(() => ripple.remove(), 600);
    }

    enhanceFormValidation() {
        // Real-time validation for forms
        document.addEventListener('input', (e) => {
            const input = e.target;
            if (input.tagName === 'INPUT' || input.tagName === 'TEXTAREA') {
                this.validateInputRealTime(input);
            }
        });

        document.addEventListener('blur', (e) => {
            const input = e.target;
            if (input.tagName === 'INPUT' || input.tagName === 'TEXTAREA') {
                this.validateInputRealTime(input);
            }
        });
    }

    validateInputRealTime(input) {
        // Remove existing error styling
        input.style.borderColor = '';
        const existingError = input.parentElement.querySelector('.form-error');
        if (existingError) {
            existingError.remove();
        }

        // Basic validation
        let isValid = true;
        let errorMessage = '';

        if (input.hasAttribute('required') && !input.value.trim()) {
            isValid = false;
            errorMessage = 'This field is required';
        } else if (input.type === 'email' && input.value && !this.isValidEmail(input.value)) {
            isValid = false;
            errorMessage = 'Please enter a valid email address';
        } else if (input.type === 'tel' && input.value && !window.isValidPhoneNumber(input.value)) {
            isValid = false;
            errorMessage = 'Please enter a valid phone number';
        } else if (input.type === 'url' && input.value && !this.isValidURL(input.value)) {
            isValid = false;
            errorMessage = 'Please enter a valid URL';
        }

        if (!isValid) {
            input.style.borderColor = 'var(--danger-color)';
            const error = document.createElement('div');
            error.className = 'form-error';
            error.style.cssText = 'color: var(--danger-color); font-size: 0.8rem; margin-top: 0.25rem;';
            error.textContent = errorMessage;
            input.parentElement.appendChild(error);
        }
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    isValidURL(url) {
        try {
            new URL(url);
            return true;
        } catch {
            return false;
        }
    }

    enhanceTableInteractions() {
        // Add row hover effects and selection
        document.addEventListener('mouseover', (e) => {
            const row = e.target.closest('tbody tr');
            if (row) {
                row.style.backgroundColor = '#f8fafc';
            }
        });

        document.addEventListener('mouseout', (e) => {
            const row = e.target.closest('tbody tr');
            if (row) {
                row.style.backgroundColor = '';
            }
        });
    }

    initTooltips() {
        // Simple tooltip implementation
        document.addEventListener('mouseover', (e) => {
            const element = e.target.closest('[data-tooltip]');
            if (element) {
                this.showTooltip(element, element.getAttribute('data-tooltip'));
            }
        });

        document.addEventListener('mouseout', (e) => {
            const element = e.target.closest('[data-tooltip]');
            if (element) {
                this.hideTooltip();
            }
        });
    }

    showTooltip(element, text) {
        const tooltip = document.createElement('div');
        tooltip.id = 'tooltip';
        tooltip.textContent = text;
        tooltip.style.cssText = `
            position: absolute;
            background: #333;
            color: white;
            padding: 0.5rem;
            border-radius: 4px;
            font-size: 0.8rem;
            z-index: 1000;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.2s;
        `;
        
        document.body.appendChild(tooltip);
        
        const rect = element.getBoundingClientRect();
        tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
        tooltip.style.top = rect.top - tooltip.offsetHeight - 5 + 'px';
        
        setTimeout(() => tooltip.style.opacity = '1', 10);
    }

    hideTooltip() {
        const tooltip = document.getElementById('tooltip');
        if (tooltip) {
            tooltip.remove();
        }
    }

    initCopyButtons() {
        document.addEventListener('click', (e) => {
            const copyBtn = e.target.closest('[data-copy]');
            if (copyBtn) {
                const textToCopy = copyBtn.getAttribute('data-copy');
                window.copyToClipboard(textToCopy);
            }
        });
    }

    // Utility methods for app management
    showMaintenanceMode() {
        const maintenanceOverlay = document.createElement('div');
        maintenanceOverlay.id = 'maintenance-overlay';
        maintenanceOverlay.innerHTML = `
            <div style="
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.8);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 9999;
                color: white;
                text-align: center;
            ">
                <div>
                    <i class="fas fa-tools fa-3x" style="margin-bottom: 1rem;"></i>
                    <h2>Maintenance Mode</h2>
                    <p>The system is currently under maintenance. Please try again later.</p>
                </div>
            </div>
        `;
        document.body.appendChild(maintenanceOverlay);
    }

    hideMaintenanceMode() {
        const overlay = document.getElementById('maintenance-overlay');
        if (overlay) {
            overlay.remove();
        }
    }

    // Error handling
    handleGlobalError(error) {
        console.error('Global error:', error);
        
        if (error.message.includes('Network')) {
            window.showToast('error', 'Network Error', 'Please check your internet connection');
        } else if (error.message.includes('Unauthorized')) {
            window.showToast('error', 'Session Expired', 'Please log in again');
            window.authManager.logout();
        } else {
            window.showToast('error', 'Error', 'An unexpected error occurred');
        }
    }

    // Cleanup
    destroy() {
        if (this.autoRefreshInterval) {
            clearInterval(this.autoRefreshInterval);
            this.autoRefreshInterval = null;
        }
        
        this.isInitialized = false;
        console.log('XMSBRA Dashboard destroyed');
    }
}

// Global error handler
window.addEventListener('error', (e) => {
    if (window.xmsbraApp) {
        window.xmsbraApp.handleGlobalError(e.error);
    }
});

// Unhandled promise rejection handler
window.addEventListener('unhandledrejection', (e) => {
    if (window.xmsbraApp) {
        window.xmsbraApp.handleGlobalError(e.reason);
    }
});

// Initialize the application
const xmsbraApp = new XMSBRAApp();
window.xmsbraApp = xmsbraApp;

// Start the application
xmsbraApp.init();

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (window.xmsbraApp) {
        window.xmsbraApp.destroy();
    }
});

