// XMSBRA Authentication Module

class AuthManager {
    constructor() {
        this.token = localStorage.getItem(CONFIG.TOKEN_KEY);
        this.user = JSON.parse(localStorage.getItem(CONFIG.USER_KEY) || 'null');
        this.isAuthenticated = !!this.token && !!this.user;
    }

    async login(username, password) {
        try {
            const response = await fetch(`${CONFIG.API_BASE_URL}/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || CONFIG.ERRORS.UNAUTHORIZED);
            }

            // Store authentication data
            this.token = data.token;
            this.user = data.user;
            this.isAuthenticated = true;

            localStorage.setItem(CONFIG.TOKEN_KEY, this.token);
            localStorage.setItem(CONFIG.USER_KEY, JSON.stringify(this.user));

            return { success: true, user: this.user };
        } catch (error) {
            console.error('Login error:', error);
            return { success: false, error: error.message };
        }
    }

    logout() {
        this.token = null;
        this.user = null;
        this.isAuthenticated = false;

        localStorage.removeItem(CONFIG.TOKEN_KEY);
        localStorage.removeItem(CONFIG.USER_KEY);

        // Redirect to login
        this.showLogin();
    }

    getAuthHeaders() {
        return {
            'Authorization': `Bearer ${this.token}`,
            'Content-Type': 'application/json'
        };
    }

    hasPermission(permission) {
        if (!this.user || !this.user.role) return false;
        
        const userPermissions = CONFIG.PERMISSIONS[this.user.role] || [];
        return userPermissions.includes(permission);
    }

    getUserRole() {
        return this.user?.role || 'guest';
    }

    getUserInfo() {
        return this.user;
    }

    showLogin() {
        document.getElementById('loginModal').style.display = 'flex';
        document.getElementById('dashboard').style.display = 'none';
    }

    showDashboard() {
        document.getElementById('loginModal').style.display = 'none';
        document.getElementById('dashboard').style.display = 'grid';
        
        // Update UI based on user role
        this.updateUIForRole();
        
        // Load default page
        window.pageManager.loadPage('overview');
    }

    updateUIForRole() {
        const role = this.getUserRole();
        const userRoleElement = document.getElementById('userRole');
        
        if (userRoleElement) {
            userRoleElement.textContent = role.toUpperCase();
            userRoleElement.className = `user-role ${role}`;
        }

        // Show/hide navigation sections based on role
        const ownerSection = document.getElementById('ownerSection');
        const bugMenuSection = document.getElementById('bugMenuSection');
        const senderSection = document.getElementById('senderSection');

        if (role === 'owner') {
            ownerSection.style.display = 'block';
            bugMenuSection.style.display = 'block';
            senderSection.style.display = 'block';
        } else if (role === 'admin') {
            ownerSection.style.display = 'none';
            bugMenuSection.style.display = 'block';
            senderSection.style.display = 'block';
        } else if (role === 'premium') {
            ownerSection.style.display = 'none';
            bugMenuSection.style.display = 'none';
            senderSection.style.display = 'block';
        }

        // Hide navigation items user doesn't have permission for
        this.updateNavigationPermissions();
    }

    updateNavigationPermissions() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            const page = link.getAttribute('data-page');
            const permission = this.getPermissionForPage(page);
            
            if (permission && !this.hasPermission(permission)) {
                link.style.display = 'none';
            } else {
                link.style.display = 'flex';
            }
        });
    }

    getPermissionForPage(page) {
        const pagePermissions = {
            'add-sender': 'add_sender',
            'list-sender': 'list_sender',
            'xata-delay': 'bug_menu',
            'force-close': 'force_close',
            'crash-target': 'crash_target',
            'user-management': 'user_management',
            'premium-control': 'premium_control',
            'system-config': 'system_config',
            'cooldown-settings': 'cooldown_settings',
            'token-validator': 'token_validator',
            'wa-channel-info': 'wa_channel_info'
        };
        
        return pagePermissions[page];
    }

    async validateToken() {
        if (!this.token) return false;

        try {
            const response = await fetch(`${CONFIG.API_BASE_URL}/auth/validate`, {
                method: 'GET',
                headers: this.getAuthHeaders()
            });

            if (response.ok) {
                const data = await response.json();
                this.user = data.user;
                localStorage.setItem(CONFIG.USER_KEY, JSON.stringify(this.user));
                return true;
            } else {
                this.logout();
                return false;
            }
        } catch (error) {
            console.error('Token validation error:', error);
            this.logout();
            return false;
        }
    }

    async refreshToken() {
        try {
            const response = await fetch(`${CONFIG.API_BASE_URL}/auth/refresh`, {
                method: 'POST',
                headers: this.getAuthHeaders()
            });

            if (response.ok) {
                const data = await response.json();
                this.token = data.token;
                localStorage.setItem(CONFIG.TOKEN_KEY, this.token);
                return true;
            } else {
                this.logout();
                return false;
            }
        } catch (error) {
            console.error('Token refresh error:', error);
            this.logout();
            return false;
        }
    }

    // Auto-refresh token before expiry
    startTokenRefresh() {
        // Refresh token every 14 minutes (assuming 15-minute expiry)
        setInterval(() => {
            if (this.isAuthenticated) {
                this.refreshToken();
            }
        }, 14 * 60 * 1000);
    }
}

// Initialize auth manager
const authManager = new AuthManager();

// Login form handler
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const logoutBtn = document.getElementById('logoutBtn');

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            
            if (!username || !password) {
                window.showToast('error', 'Error', 'Please fill in all fields');
                return;
            }

            // Show loading state
            const submitBtn = loginForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Logging in...';
            submitBtn.disabled = true;

            const result = await authManager.login(username, password);
            
            // Reset button state
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;

            if (result.success) {
                window.showToast('success', 'Success', CONFIG.SUCCESS.LOGIN);
                authManager.showDashboard();
                
                // Clear form
                loginForm.reset();
            } else {
                window.showToast('error', 'Login Failed', result.error);
            }
        });
    }

    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            authManager.logout();
            window.showToast('success', 'Success', CONFIG.SUCCESS.LOGOUT);
        });
    }

    // Check if user is already authenticated
    if (authManager.isAuthenticated) {
        authManager.validateToken().then(isValid => {
            if (isValid) {
                authManager.showDashboard();
            } else {
                authManager.showLogin();
            }
        });
    } else {
        authManager.showLogin();
    }

    // Start token refresh timer
    authManager.startTokenRefresh();
});

// Export for use in other modules
window.authManager = authManager;

