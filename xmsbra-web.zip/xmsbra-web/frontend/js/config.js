// XMSBRA Dashboard Configuration

const CONFIG = {
    // API Configuration
    API_BASE_URL: 'https://your-worker.your-subdomain.workers.dev',
    
    // Authentication
    TOKEN_KEY: 'xmsbra_token',
    USER_KEY: 'xmsbra_user',
    
    // Bot Configuration
    BOT_NAME: 'XMSBRA Bot',
    VERSION: '1.1.0',
    
    // UI Configuration
    TOAST_DURATION: 5000,
    AUTO_REFRESH_INTERVAL: 30000, // 30 seconds
    
    // Role Permissions
    PERMISSIONS: {
        owner: [
            'add_sender', 'list_sender', 'delete_sender',
            'bug_menu', 'force_close', 'crash_target',
            'user_management', 'premium_control', 'system_config',
            'cooldown_settings', 'token_validator', 'wa_channel_info'
        ],
        admin: [
            'add_sender', 'list_sender',
            'bug_menu', 'force_close',
            'wa_channel_info'
        ],
        premium: [
            'add_sender', 'list_sender',
            'wa_channel_info'
        ]
    },
    
    // Default Cooldown Settings
    DEFAULT_COOLDOWN: {
        time: 5 * 60 * 1000, // 5 minutes in milliseconds
        unit: 'm'
    },
    
    // WhatsApp Session Configuration
    WA_SESSION: {
        MAX_SESSIONS: 10,
        PAIRING_TIMEOUT: 120000, // 2 minutes
        RECONNECT_DELAY: 5000 // 5 seconds
    },
    
    // Bug Menu Configuration
    BUG_MENU: {
        XATA_DELAY: {
            name: 'Xata Force Delay',
            description: 'Send delay bug message to target',
            cooldown: 30000 // 30 seconds
        },
        FORCE_CLOSE: {
            name: 'Force Close',
            description: 'Force close WhatsApp application',
            cooldown: 60000 // 1 minute
        },
        CRASH_TARGET: {
            name: 'Crash Target',
            description: 'Send crash message to target',
            cooldown: 120000 // 2 minutes
        }
    },
    
    // Status Messages
    STATUS: {
        ONLINE: 'online',
        OFFLINE: 'offline',
        CONNECTING: 'connecting',
        ERROR: 'error',
        PAIRING: 'pairing'
    },
    
    // Error Messages
    ERRORS: {
        UNAUTHORIZED: 'Unauthorized access',
        FORBIDDEN: 'Access forbidden',
        NOT_FOUND: 'Resource not found',
        SERVER_ERROR: 'Server error occurred',
        NETWORK_ERROR: 'Network connection error',
        INVALID_INPUT: 'Invalid input provided',
        COOLDOWN_ACTIVE: 'Cooldown is still active'
    },
    
    // Success Messages
    SUCCESS: {
        LOGIN: 'Login successful',
        LOGOUT: 'Logout successful',
        SENDER_ADDED: 'Sender added successfully',
        SENDER_DELETED: 'Sender deleted successfully',
        BUG_SENT: 'Bug message sent successfully',
        CONFIG_UPDATED: 'Configuration updated successfully',
        USER_CREATED: 'User created successfully',
        USER_UPDATED: 'User updated successfully',
        PREMIUM_UPDATED: 'Premium status updated successfully'
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}

